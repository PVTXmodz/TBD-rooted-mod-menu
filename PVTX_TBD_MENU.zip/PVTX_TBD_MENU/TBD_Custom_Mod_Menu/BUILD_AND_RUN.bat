@echo off
setlocal EnableExtensions EnableDelayedExpansion
title Tag Before Dawn - PVTX Custom Menu (USB / Stable TCP 5555)
set "BASE=%~dp0"
set "ADB=%BASE%platform-tools\adb.exe"
set "PACKAGE=com.Cydream.TagBeforeDawn"
set "PAYLOAD=%BASE%tagbeforedawnmod.js"
set "PREFERRED="

rem frida-compile 16.x resolves its embedded TypeScript library incorrectly when this path contains spaces.
if not "%BASE%"=="%BASE: =%" (
  echo [ERROR] This project path contains spaces, which breaks this version of frida-compile.
  echo Move the folder to a path without spaces, for example C:\TBD_PVTX\TBD_Custom_Mod_Menu, then run this BAT again.
  goto :fail
)

echo ============================================================
echo   Tag Before Dawn - PVTX Custom Menu
echo   USB / Wireless ADB TCP-IP (port 5555)
echo ============================================================
if not exist "%ADB%" (
  echo [ERROR] Missing platform-tools\adb.exe
  echo Place the Android SDK platform-tools folder beside this BAT.
  goto :fail
)
where node >nul 2>&1 || (echo [ERROR] Node.js not found in PATH.& goto :fail)
where npm >nul 2>&1 || (echo [ERROR] npm not found in PATH.& goto :fail)
where frida >nul 2>&1 || (echo [ERROR] Frida CLI not found in PATH. Install frida-tools and ensure frida.exe is on PATH.& goto :fail)

pushd "%BASE%"
echo.
echo [1/5] Installing project dependencies...
call npm install
if errorlevel 1 (echo [ERROR] npm install failed.& goto :fail)

echo.
echo [2/5] Checking the local Frida compiler...
if not exist "%BASE%node_modules\frida-compile\dist\cli.js" (
  echo [WARN] Local frida-compile files are missing. Repairing that dependency...
  call npm install --save-dev frida-compile@16.4.2
  if errorlevel 1 (echo [ERROR] Could not repair frida-compile.& goto :fail)
)
if not exist "%BASE%node_modules\frida-compile\ext\lib.es2020.d.ts" (
  echo [WARN] The Frida TypeScript standard library is missing. Reinstalling frida-compile...
  call npm install --save-dev frida-compile@16.4.2
  if errorlevel 1 (echo [ERROR] Could not reinstall frida-compile.& goto :fail)
)
if not exist "%BASE%node_modules\frida-compile\ext\lib.es2020.d.ts" (
  echo [ERROR] lib.es2020.d.ts is still missing after reinstall.
  echo Close this window, check your internet connection, then run BUILD_AND_RUN.bat again.
  goto :fail
)
echo.
echo [2/5] Compiling with this project's local Frida compiler...
node "%BASE%node_modules\frida-compile\dist\cli.js" "%BASE%tagbeforedawnmod.ts" -o "%PAYLOAD%"
if errorlevel 1 (echo [ERROR] TypeScript payload compilation failed.& goto :fail)
if not exist "%PAYLOAD%" (echo [ERROR] Compiler did not produce tagbeforedawnmod.js.& goto :fail)

echo.
echo [3/5] Connection method:
echo   1. Use an already connected device (USB or wireless)
echo   2. Connect to an existing wireless ADB IP:PORT (pairing already done)
echo   3. Enable TCP/IP over USB and connect on port 5555 (recommended if Wireless debugging turns off)
set "METHOD="
set /p "METHOD=Choose 1-3: "
if "!METHOD!"=="2" goto :direct
if "!METHOD!"=="3" goto :tcpip
if not "!METHOD!"=="1" (echo [ERROR] Invalid choice.& goto :fail)
goto :devices

:direct
echo.
echo Enter the full IP:PORT from the Quest's main Wireless debugging screen.
echo Example only: 192.168.1.188:36181
set "CONNECTADDR="
set /p "CONNECTADDR=Device IP:PORT: "
if not defined CONNECTADDR (echo [ERROR] Address required.& goto :fail)
if not "!CONNECTADDR!:x"=="!CONNECTADDR:~0,1!x" rem validation intentionally handled by adb below
"%ADB%" connect "!CONNECTADDR!"
if errorlevel 1 (echo [ERROR] ADB connect failed.& goto :fail)
set "PREFERRED=!CONNECTADDR!"
goto :devices

:tcpip
echo.
echo 1. Connect the Quest to this PC by USB.
echo 2. Put on the headset and accept the USB debugging prompt.
echo 3. The PC and Quest must be on the same trusted Wi-Fi network.
"%ADB%" devices
set "USBSERIAL="
set /p "USBSERIAL=Enter the USB serial shown above (example 340YC10G8M057G): "
if not defined USBSERIAL (echo [ERROR] USB serial required.& goto :fail)
"%ADB%" -s "!USBSERIAL!" get-state 2>nul | findstr /x "device" >nul
if errorlevel 1 (echo [ERROR] That serial is not an authorized online device. Check the serial and USB prompt.& goto :fail)
echo.
echo Enabling ADB TCP/IP on port 5555...
"%ADB%" -s "!USBSERIAL!" tcpip 5555
if errorlevel 1 (echo [ERROR] Could not enable TCP/IP over USB.& goto :fail)
echo.
echo Find the Quest's Wi-Fi IP address in its Wi-Fi network details.
echo Enter the IP ADDRESS ONLY, not a port. Example: 192.168.1.188
set "DEVICEIP="
set /p "DEVICEIP=Quest Wi-Fi IP address: "
if not defined DEVICEIP (echo [ERROR] IP address required.& goto :fail)
echo(!DEVICEIP!| findstr /r "^[0-9][0-9]*\.[0-9][0-9]*\.[0-9][0-9]*\.[0-9][0-9]*$" >nul
if errorlevel 1 (echo [ERROR] That does not look like an IPv4 address. Enter the address such as 192.168.1.188, not a port like 39963.& goto :fail)
set "PREFERRED=!DEVICEIP!:5555"
echo.
echo Connecting to !PREFERRED! ...
"%ADB%" connect "!PREFERRED!"
if errorlevel 1 (echo [ERROR] Wireless TCP/IP connection failed. Check the IP, same Wi-Fi, and firewall/router isolation.& goto :fail)
"%ADB%" -s "!PREFERRED!" get-state 2>nul | findstr /x "device" >nul
if errorlevel 1 (echo [ERROR] !PREFERRED! did not reach authorized device state.& goto :fail)
echo [OK] TCP/IP connection established at !PREFERRED!.
echo You can now unplug USB. Keep this console open while Frida runs.
goto :devices

:devices
echo.
echo Available online ADB devices:
"%ADB%" devices
set /a COUNT=0
for /f "skip=1 tokens=1,2" %%A in ('"%ADB%" devices') do (
  if "%%B"=="device" (
    set /a COUNT+=1
    set "DEV!COUNT!=%%A"
    echo   !COUNT!. %%A
  )
)
if !COUNT! EQU 0 (echo [ERROR] No authorized online ADB device found.& goto :fail)
set "SERIAL="
if defined PREFERRED (
  for /l %%N in (1,1,!COUNT!) do if /i "!DEV%%N!"=="!PREFERRED!" set "SERIAL=!DEV%%N!"
  if not defined SERIAL (echo [ERROR] Preferred device !PREFERRED! is not in the online device list.& goto :fail)
) else if !COUNT! EQU 1 (
  set "SERIAL=!DEV1!"
) else (
  echo.
  echo Enter the NUMBER or paste the exact device serial/IP:PORT from the list.
  set /p "CHOICE=Device: "
  for /l %%N in (1,1,!COUNT!) do if /i "!CHOICE!"=="!DEV%%N!" set "SERIAL=!DEV%%N!"
  if not defined SERIAL for /l %%N in (1,1,!COUNT!) do if "!CHOICE!"=="%%N" set "SERIAL=!DEV%%N!"
)
if not defined SERIAL (echo [ERROR] Invalid device selection. Enter the number, e.g. 1, not a different address.& goto :fail)
echo [OK] Selected ADB device: !SERIAL!

echo.
echo Syncing soundboard files to the Quest...
set /a AUDIOCOUNT=0
for %%F in ("%BASE%sounds\*.wav") do (
  if exist "%%~fF" (
    set /a AUDIOCOUNT+=1
    echo   Local audio: %%~nxF
  )
)
for %%F in ("%BASE%sounds\*.mp3") do (
  if exist "%%~fF" (
    set /a AUDIOCOUNT+=1
    echo   Local audio: %%~nxF
  )
)
echo [INFO] Local WAV/MP3 count: !AUDIOCOUNT!
if !AUDIOCOUNT! EQU 0 echo [WARN] No .wav or .mp3 files found in "%BASE%sounds".
"%ADB%" -s "!SERIAL!" shell mkdir -p /sdcard/Android/data/com.Cydream.TagBeforeDawn/files/PVTXSounds
if exist "%BASE%sounds\." (
  "%ADB%" -s "!SERIAL!" push "%BASE%sounds\." /sdcard/Android/data/com.Cydream.TagBeforeDawn/files/PVTXSounds/
  if errorlevel 1 (echo [ERROR] Sound sync failed. Check the ADB output above.) else echo [OK] Sound folder push command completed.
) else (
  echo [ERROR] Local sounds folder not found: "%BASE%sounds"
)
echo.
echo [INFO] WAV/MP3 files currently visible on the Quest:
"%ADB%" -s "!SERIAL!" shell ls -la /sdcard/Android/data/com.Cydream.TagBeforeDawn/files/PVTXSounds
echo [INFO] This VC build sends PCM16 WAV only. MP3s are copied and listed, but convert them using CONVERT_MP3_TO_VC_WAV.bat.

rem Confirm selected transport remains online before starting the game.
"%ADB%" -s "!SERIAL!" get-state 2>nul | findstr /x "device" >nul
if errorlevel 1 (echo [ERROR] Selected device is no longer online.& goto :fail)

echo.
echo [4/5] Launching %PACKAGE%...
"%ADB%" -s "!SERIAL!" shell monkey -p "%PACKAGE%" 1
if errorlevel 1 echo [WARN] Launcher command returned non-zero; checking process anyway.
set "PID="
for /l %%N in (1,1,60) do (
  if not defined PID (
    "%ADB%" -s "!SERIAL!" shell pidof "%PACKAGE%" > "%TEMP%\tbd_custom_pid.txt" 2>nul
    set /p PID=<"%TEMP%\tbd_custom_pid.txt"
    for /f "tokens=1" %%P in ("!PID!") do set "PID=%%P"
  )
  if not defined PID timeout /t 1 /nobreak >nul
)
if not defined PID (echo [ERROR] Game process was not found after 60 seconds.& goto :fail)
echo [OK] Game PID: !PID!

echo.
echo [5/5] Attaching Frida. Keep this window open.
echo NOTE: TCP/IP on port 5555 may reset after reboot or network change.
echo NOTE: if the Quest disables ADB itself, this connection can still drop.
echo NOTE: look for '[PVTX] first tick received' and 'STEP FAILED' diagnostics.
frida -D "!SERIAL!" -p "!PID!" -l "%PAYLOAD%"
echo.
echo Frida session ended. Review diagnostics above.
popd
pause
exit /b 0

:fail
if defined BASE popd 2>nul
echo.
echo The process stopped because of an error. The console will remain open.
pause
exit /b 1
