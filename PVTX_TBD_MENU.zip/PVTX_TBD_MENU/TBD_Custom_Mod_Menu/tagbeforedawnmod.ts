declare const console: { log: (...a: any[]) => void; error: (...a: any[]) => void; warn: (...a: any[]) => void };
declare function setTimeout(cb: () => void, ms: number): any;
declare function setInterval(cb: () => void, ms: number): any;
declare function clearInterval(id: any): void;
declare const Java: any;
declare const Interceptor: { attach(target: any, callbacks: { onEnter?: (args: any) => void; onLeave?: (retval: any) => void }) : any };
declare const rpc: { exports: any };
import "frida-il2cpp-bridge";

/*
 * PVTX | TAG BEFORE DAWN  -  milestone 1+2 payload (UNTESTED IN HEADSET)
 *
 * What this does:
 *  - Builds ONE world-space Unity UI canvas ("PVTX_MENU_ROOT") with plain Unity UI parts
 *    (GameObject/Canvas/Image/TMP). It never touches MenuManager.OpenMenu/OpenGraphicMenu.
 *  - Does NOT use EventSystem/Button/UnityAction. Interaction is done by this script itself:
 *    a ray from the right hand (GTController.rightHandTransform) is intersected with the panel plane,
 *    and the right trigger (InputProcessor.rightTriggerPressed) clicks. This avoids having to build
 *    IL2CPP delegates and does not depend on the game's input module.
 *  - Open/close: hold LEFT GRIP + LEFT TRIGGER together (edge-triggered).
 *  - Player-dependent parts (hands, trigger, movement) enable only after GTPlayer.localPlayer is verified.
 *
 * Every Unity call goes through step() so a wrong overload logs ONE clear line instead of crashing.
 */
const P = '[PVTX] ';
const log = (s: string) => console.log(P + s);

const cfg = { toggleChord: 'leftGrip+leftTrigger', scale: 1.0, distance: 0.9, follow: false, diag: true, tab: 'Movement', tpPage: 0 };
  const SOUND_DIR = '/sdcard/Android/data/com.Cydream.TagBeforeDawn/files/PVTXSounds';
  const SOUND_SLOTS = 8;
const state = {
  speed: 1.0, jump: 1.0, fly: false, flySpeed: 4.0, grav: true, noclip: false, gripPlatforms: false,
  espKiller: true, espSurvivor: true, espAll: false, espDist: true,
};
const TP_PER_PAGE = 8;

const warned: { [k: string]: boolean } = {};
function step<T>(label: string, fn: () => T, fallback: T): T {
  try { return fn(); } catch (e) {
    if (!warned[label]) { warned[label] = true; console.warn(P + 'STEP FAILED: ' + label + ' -> ' + e); }
    return fallback;
  }
}

Il2Cpp.perform(() => {
  // ---------- class lookup (cached, logged once) ----------
  const cache: { [k: string]: Il2Cpp.Class | null } = {};
  function K(name: string): Il2Cpp.Class | null {
    if (name in cache) return cache[name];
    let f: Il2Cpp.Class | null = null;
    for (const a of Il2Cpp.domain.assemblies) {
      try { const c = a.image.tryClass(name); if (c) { f = c; break; } } catch (_) {}
    }
    if (!f && name.indexOf('.') < 0) {   // no namespace given: match short name in any namespace
      outer: for (const a of Il2Cpp.domain.assemblies) {
        try { for (const c of a.image.classes) { if (c.name === name) { f = c; log('class ' + name + ' found as ' + c.fullName + ' (' + a.name + ')'); break outer; } } } catch (_) {}
      }
    }
    cache[name] = f;
    if (f) { if (cfg.diag) log('class ok: ' + name); } else console.warn(P + 'class MISSING: ' + name);
    return f;
  }
  const need = (n: string): Il2Cpp.Class => { const c = K(n); if (!c) throw new Error('missing class ' + n); return c; };

  // ---------- value-type helpers ----------
  const v3 = (x: number, y: number, z: number) => { const o = need('UnityEngine.Vector3').new(); o.method('.ctor', 3).invoke(x, y, z); return o.unbox(); };
  const v2 = (x: number, y: number) => { const o = need('UnityEngine.Vector2').new(); o.method('.ctor', 2).invoke(x, y); return o.unbox(); };
  const col = (r: number, g: number, b: number, a: number) => { const o = need('UnityEngine.Color').new(); o.method('.ctor', 4).invoke(r, g, b, a); return o.unbox(); };
  const rd = (v: any): [number, number, number] => [Number(v.field('x').value), Number(v.field('y').value), Number(v.field('z').value)];

  // ---------- theme ----------
  const T = {
    bg: [0.06, 0.04, 0.13, 0.94], panel: [0.10, 0.08, 0.24, 0.95], btn: [0.22, 0.12, 0.45, 1], btnHover: [0.36, 0.22, 0.75, 1],
    on: [0.15, 0.55, 0.75, 1], tabOn: [0.45, 0.2, 0.85, 1], text: [0.92, 0.9, 1, 1], dim: [0.6, 0.6, 0.8, 1], cursor: [0.5, 0.9, 1, 1],
  };

  // ---------- Unity object builders ----------
  interface Node { go: Il2Cpp.Object; tf: Il2Cpp.Object; rt: Il2Cpp.Object }
  function mk(name: string, parent: Il2Cpp.Object | null): Node {
    const go = need('UnityEngine.GameObject').new();
    go.method('.ctor', 1).invoke(Il2Cpp.string(name));
    const rt = go.method('AddComponent', 1).invoke(need('UnityEngine.RectTransform').type.object) as Il2Cpp.Object;
    if (parent) rt.method('SetParent', 2).invoke(parent, false);
    return { go, tf: rt, rt };
  }
  function place(n: Node, x: number, y: number, w: number, h: number) {
    n.rt.method('set_anchorMin').invoke(v2(0.5, 0.5)); n.rt.method('set_anchorMax').invoke(v2(0.5, 0.5));
    n.rt.method('set_pivot').invoke(v2(0.5, 0.5));
    n.rt.method('set_sizeDelta').invoke(v2(w, h)); n.rt.method('set_anchoredPosition').invoke(v2(x, y));
  }
  function img(n: Node, c: number[]): Il2Cpp.Object {
    const i = n.go.method('AddComponent', 1).invoke(need('UnityEngine.UI.Image').type.object) as Il2Cpp.Object;
    i.method('set_color').invoke(col(c[0], c[1], c[2], c[3])); return i;
  }
  function label(parent: Il2Cpp.Object, text: string, size: number, x: number, y: number, w: number, h: number, c = T.text): Il2Cpp.Object {
    const n = mk('txt', parent); place(n, x, y, w, h);
    if (cfg.diag && !warned['__tmp1']) { warned['__tmp1'] = true; log('adding first TextMeshProUGUI...'); }
    const t = n.go.method('AddComponent', 1).invoke(need('TMPro.TextMeshProUGUI').type.object) as Il2Cpp.Object;
    if (cfg.diag && !warned['__tmp2']) { warned['__tmp2'] = true; log('first TextMeshProUGUI added OK'); }
    t.method('set_text').invoke(Il2Cpp.string(text)); t.method('set_fontSize').invoke(size);
    t.method('set_color').invoke(col(c[0], c[1], c[2], c[3]));
    step('tmp alignment', () => t.method('set_alignment').invoke(514), null); // TextAlignmentOptions.Center = 514
    return t;
  }

  // ---------- menu model ----------
  interface Btn { id: string; tab: string; x: number; y: number; w: number; h: number; image: Il2Cpp.Object; textObj: Il2Cpp.Object; onClick: () => void; on?: () => boolean; baseText: () => string }
  const btns: Btn[] = [];
  const tabRoots: { [t: string]: Node } = {};
  let root: Node | null = null, canvasObj: Il2Cpp.Object | null = null, cursor: Node | null = null, infoText: Il2Cpp.Object | null = null;
  let menuOpen = false, hover: Btn | null = null, builtOnce = false;

  function addBtn(tab: string, id: string, x: number, y: number, w: number, h: number, text: () => string, onClick: () => void, on?: () => boolean) {
    const parent = tab === '*' ? root!.tf : tabRoots[tab].tf;
    const n = mk('btn_' + id, parent); place(n, x, y, w, h);
    const image = img(n, T.btn);
    const t = label(n.tf, text(), 26, 0, 0, w, h);
    btns.push({ id, tab, x, y, w, h, image, textObj: t, onClick, on, baseText: text });
  }
  function refreshBtn(b: Btn) {
    step('refresh ' + b.id, () => {
      b.textObj.method('set_text').invoke(Il2Cpp.string(b.baseText()));
      const c = b === hover ? T.btnHover : (b.tab === '*' && b.on && b.on() ? T.tabOn : (b.on && b.on() ? T.on : T.btn));
      b.image.method('set_color').invoke(col(c[0], c[1], c[2], c[3]));
    }, null);
  }

  // ---------- player ----------
  let player: Il2Cpp.Object | null = null, ctrl: Il2Cpp.Object | null = null, inputP: Il2Cpp.Object | null = null, playerLogged = false;
  function findPlayer() {
    const classNames = ['GTPlayer', 'Cydream.GTPlayer', 'Player', 'Cydream.Player', 'LocalPlayer'];
    let pc: Il2Cpp.Class | null = null;
    for (const n of classNames) { pc = K(n); if (pc) break; }
    if (!pc) return;
    const fieldNames = ['localPlayer', 'Instance', 'instance', 'Local', 'local'];
    let p: Il2Cpp.Object | null = null;
    for (const fn of fieldNames) {
      p = step('player.' + fn, () => {
        try {
          const v = pc!.field(fn).value as Il2Cpp.Object;
          return v && !v.isNull() ? v : null;
        } catch (_) { return null; }
      }, null);
      if (p) break;
    }
    if (p && !p.isNull()) {
      const ctrlFields = ['controller', 'Controller', 'gtController', 'playerController'];
      let c: Il2Cpp.Object | null = null;
      for (const cf of ctrlFields) {
        c = step('ctrl.' + cf, () => {
          try {
            const v = p!.field(cf).value as Il2Cpp.Object;
            return v && !v.isNull() ? v : null;
          } catch (_) { return null; }
        }, null);
        if (c) break;
      }
      if (c && !c.isNull()) {
        player = p; ctrl = c;
        inputP = step('inputP', () => {
          for (const inf of ['inputProcessor', 'InputProcessor', 'input', 'rawInput']) {
            try {
              const v = c!.field(inf).value as Il2Cpp.Object;
              if (v && !v.isNull()) return v;
            } catch (_) {}
          }
          // Fallback: static InputProcessor instance
          const ic = K('Cydream.InputProcessor') || K('InputProcessor');
          if (ic) {
            for (const inf of ['Instance', 'instance', 'local', 'Local']) {
              try {
                const v = ic.field(inf).value as Il2Cpp.Object;
                if (v && !v.isNull()) return v;
              } catch (_) {}
            }
          }
          return null;
        }, null);
        if (!playerLogged) {
          playerLogged = true;
          log('local player verified (controller=' + !!ctrl + ', inputProcessor=' + !!inputP + '). Interaction + movement enabled.');
        }
        return;
      }
    }
    player = null; ctrl = null; inputP = null;
  }

  // PVTX VC soundboard: one-shot PCM WAV injection into the captured microphone stream.
  // All file I/O, WAV parsing, resampling and loudness normalization happen on the UI-side
  // action, never inside AudioRecord.read. The audio hook only mixes already-prepared samples.
  let soundFiles: string[] = [];
  let activeSoundName: string | null = null;
  let soundStatusLabel: Il2Cpp.Object | null = null;
  let soundInfoLabel: Il2Cpp.Object | null = null;
  let micPlaybackSamples: number[] | null = null;
  let micPlaybackCursor = 0;
  let micPlaybackEnabled = false;
  let micHookInstalled = false;
  let micSampleRate = 48000;
  let micSampleRateObserved = false;
  let soundFinished = false;
  // Runtime evidence: distinguish a queued file from samples actually changed in the mic stream.
  let micReadCallbacks = 0;
  let micInjectionSamples = 0;
  let micReadEvidenceLogged = false;
  let micInjectionEvidenceLogged = false;
  let micPlaybackCheckId = 0;
  // Local monitor playback is separate from mic injection: the mic mix stays intact for remote players.
  let localMonitorTrack: any = null;
  const MAX_WAV_BYTES = 1024 * 1024;
  const MAX_PLAYBACK_SECONDS = 10;
  const TARGET_RMS = 12000; // raise quiet clips strongly before a soft limiter
  const MAX_NORMALIZE_GAIN = 8.0;

  function updateSoundStatus(message: string) {
    if (soundStatusLabel) step('sound status label', () => soundStatusLabel!.method('set_text').invoke(Il2Cpp.string(message)), null);
    log('soundboard: ' + message);
  }

  function clampPcm16(sample: number): number {
    if (sample > 32767) return 32767;
    if (sample < -32768) return -32768;
    return sample;
  }

  function mixSample(mic: number, sound: number): number {
    // Sound samples are peak-normalized before playback; clamp the mix to valid PCM16.
    return clampPcm16(mic + sound);
  }

  function installMicCaptureHook() {
    if (micHookInstalled) return;
    if (typeof Java === 'undefined' || !Java.available) {
      updateSoundStatus('Android Java bridge unavailable; VC audio hook could not start.');
      return;
    }
    try {
      Java.perform(() => {
        try {
          const AudioRecord = Java.use('android.media.AudioRecord');
          let hooked = false;
          try {
            const readBytes = AudioRecord.read.overload('[B', 'int', 'int');
            readBytes.implementation = function(buffer: any, offset: number, size: number) {
              const result = readBytes.call(this, buffer, offset, size);
              if (result > 0) {
                micReadCallbacks++;
                if (!micReadEvidenceLogged) {
                  micReadEvidenceLogged = true;
                  log('soundboard: Java AudioRecord.read(byte[]) is active (first result=' + Number(result) + ').');
                }
                try {
                  if (!micSampleRateObserved) {
                    try { const observed = Number(this.getSampleRate()); if (observed >= 8000 && observed <= 96000) micSampleRate = observed; } catch (_) {}
                    micSampleRateObserved = true;
                  }
                  const pcm = micPlaybackSamples;
                  if (micPlaybackEnabled && pcm && pcm.length > 0) {
                    const count = Math.min(Number(result), Number(size));
                    const evenCount = count - (count % 2);
                    let cursor = micPlaybackCursor;
                    const cursorBeforeMix = cursor;
                    for (let i = 0; i < evenCount && cursor < pcm.length; i += 2) {
                      const lo = Number(buffer[offset + i]) & 255;
                      const hi = Number(buffer[offset + i + 1]) & 255;
                      let mic = (hi << 8) | lo;
                      if (mic >= 32768) mic -= 65536;
                      const mixed = mixSample(mic, pcm[cursor++]);
                      const outLo = mixed & 255;
                      const outHi = (mixed >> 8) & 255;
                      buffer[offset + i] = outLo > 127 ? outLo - 256 : outLo;
                      buffer[offset + i + 1] = outHi > 127 ? outHi - 256 : outHi;
                    }
                    micPlaybackCursor = cursor;
                    const mixedNow = cursor - cursorBeforeMix;
                    if (mixedNow > 0) {
                      micInjectionSamples += mixedNow;
                      if (!micInjectionEvidenceLogged) {
                        micInjectionEvidenceLogged = true;
                        log('soundboard: clip samples are being mixed into Java AudioRecord byte[] capture.');
                      }
                    }
                    if (cursor >= pcm.length) { micPlaybackEnabled = false; soundFinished = true; }
                  }
                } catch (mixError) { log('soundboard byte[] mix error: ' + mixError); micPlaybackEnabled = false; soundFinished = true; }
              }
              return result;
            };
            hooked = true;
          } catch (e) { log('AudioRecord byte[] read overload unavailable: ' + e); }
          try {
            const readShorts = AudioRecord.read.overload('[S', 'int', 'int');
            readShorts.implementation = function(buffer: any, offset: number, size: number) {
              const result = readShorts.call(this, buffer, offset, size);
              if (result > 0) {
                micReadCallbacks++;
                if (!micReadEvidenceLogged) {
                  micReadEvidenceLogged = true;
                  log('soundboard: Java AudioRecord.read(short[]) is active (first result=' + Number(result) + ').');
                }
                try {
                  if (!micSampleRateObserved) {
                    try { const observed = Number(this.getSampleRate()); if (observed >= 8000 && observed <= 96000) micSampleRate = observed; } catch (_) {}
                    micSampleRateObserved = true;
                  }
                  const pcm = micPlaybackSamples;
                  if (micPlaybackEnabled && pcm && pcm.length > 0) {
                    const count = Math.min(Number(result), Number(size));
                    let cursor = micPlaybackCursor;
                    const cursorBeforeMix = cursor;
                    for (let i = 0; i < count && cursor < pcm.length; i++) {
                      const mic = Number(buffer[offset + i]);
                      buffer[offset + i] = mixSample(mic, pcm[cursor++]);
                    }
                    micPlaybackCursor = cursor;
                    const mixedNow = cursor - cursorBeforeMix;
                    if (mixedNow > 0) {
                      micInjectionSamples += mixedNow;
                      if (!micInjectionEvidenceLogged) {
                        micInjectionEvidenceLogged = true;
                        log('soundboard: clip samples are being mixed into Java AudioRecord short[] capture.');
                      }
                    }
                    if (cursor >= pcm.length) { micPlaybackEnabled = false; soundFinished = true; }
                  }
                } catch (mixError) { log('soundboard short[] mix error: ' + mixError); micPlaybackEnabled = false; soundFinished = true; }
              }
              return result;
            };
            hooked = true;
          } catch (e) { log('AudioRecord short[] read overload unavailable: ' + e); }
          if (!hooked) throw new Error('No supported AudioRecord.read overload found');
          micHookInstalled = true;
          updateSoundStatus('Java AudioRecord hook installed; actual game VC capture path is not yet verified. Choose WAV to test.');
          if (soundInfoLabel) step('sound info label', () => soundInfoLabel!.method('set_text').invoke(Il2Cpp.string('AudioRecord hook installed • VC path unverified')), null);
          log('soundboard: AudioRecord hook installed, but transmission is unverified. The first actual read and first mixed sample will be logged separately.');
        } catch (e) {
          updateSoundStatus('VC audio hook failed: ' + e);
          if (soundInfoLabel) step('sound info label', () => soundInfoLabel!.method('set_text').invoke(Il2Cpp.string('VC hook failed; see Frida log')), null);
        }
      });
    } catch (e) { updateSoundStatus('Could not initialize VC audio hook: ' + e); }
  }

  function readWavBytes(file: any): any {
    const FileInputStream = Java.use('java.io.FileInputStream');
    const ByteArrayOutputStream = Java.use('java.io.ByteArrayOutputStream');
    const fis = FileInputStream.$new(file);
    const bos = ByteArrayOutputStream.$new();
    const temp = Java.array('byte', new Array(8192).fill(0));
    try {
      let n = 0;
      while ((n = Number(fis.read(temp))) > 0) bos.write(temp, 0, n);
      return bos.toByteArray();
    } finally {
      try { fis.close(); } catch (_) {}
      try { bos.close(); } catch (_) {}
    }
  }

  // Local monitor uses MODE_STREAM and writes small chunks from a worker thread.
  // WAV conversion is also split into short batches so a large clip cannot monopolize
  // Frida's JS event loop and stall the game.
  let localPlaybackToken = 0;
  let localPlaybackClassId = 0;
  function stopLocalMonitorPlayback() {
    localPlaybackToken++;
    const oldTrack = localMonitorTrack;
    localMonitorTrack = null;
    if (oldTrack && typeof Java !== 'undefined' && Java.available) {
      Java.perform(() => {
        try { oldTrack.pause(); } catch (_) {}
        try { oldTrack.flush(); } catch (_) {}
        try { oldTrack.stop(); } catch (_) {}
        try { oldTrack.release(); } catch (_) {}
      });
    }
  }

  function startLocalMonitorPlayback(samples: number[], sampleRate: number, name: string) {
    if (!samples || samples.length < 1) return;
    const token = ++localPlaybackToken;
    Java.perform(() => {
      try {
        if (token !== localPlaybackToken) return;
        const AudioTrack = Java.use('android.media.AudioTrack');
        const Thread = Java.use('java.lang.Thread');
        const minBytes = Number(AudioTrack.getMinBufferSize(sampleRate, 4, 2));
        if (minBytes < 0) throw new Error('AudioTrack.getMinBufferSize failed: ' + minBytes);
        const bufferBytes = Math.max(8192, minBytes * 2);
        // Stream mode (1) avoids allocating/writing a full clip into a static track.
        const track = AudioTrack.$new(3, sampleRate, 4, 2, bufferBytes, 1);
        const state = Number(track.getState());
        if (state !== 1) { try { track.release(); } catch (_) {} throw new Error('AudioTrack not initialized (state=' + state + ')'); }
        localMonitorTrack = track;
        track.play();
        const className = 'com.pvtx.SoundboardWriter' + (++localPlaybackClassId);
        const Writer = Java.registerClass({
          name: className,
          implements: [Java.use('java.lang.Runnable')],
          methods: {
            run: function() {
              try {
                const chunkSize = 4096;
                for (let offset = 0; offset < samples.length; offset += chunkSize) {
                  if (token !== localPlaybackToken || localMonitorTrack !== track) break;
                  const end = Math.min(samples.length, offset + chunkSize);
                  const chunk = Java.array('short', samples.slice(offset, end));
                  let written = 0;
                  while (written < chunk.length && token === localPlaybackToken && localMonitorTrack === track) {
                    const n = Number(track.write(chunk, written, chunk.length - written));
                    if (n <= 0) throw new Error('AudioTrack.write failed: ' + n);
                    written += n;
                  }
                }
                if (token === localPlaybackToken && localMonitorTrack === track) {
                  try { track.stop(); } catch (_) {}
                  try { track.release(); } catch (_) {}
                  localMonitorTrack = null;
                  log('soundboard: local headset playback finished for ' + name);
                }
              } catch (e) {
                if (token === localPlaybackToken) log('soundboard: local headset playback worker failed: ' + e);
              }
            }
          }
        });
        Thread.$new(Writer.$new()).start();
        log('soundboard: local headset playback started (streaming) for ' + name + ' (' + samples.length + ' samples).');
      } catch (e) {
        log('soundboard: local headset playback failed: ' + e);
      }
    });
  }

  function loadWavForMic(name: string) {
    if (!/\.wav$/i.test(name)) { updateSoundStatus('MP3 detected: listed correctly, but VC injection needs PCM16 WAV. Run CONVERT_MP3_TO_VC_WAV.bat on the PC, then Refresh Sounds.'); return; }
    if (!micHookInstalled) { updateSoundStatus('VC audio hook is not ready yet; check the Frida log.'); return; }
    if (typeof Java === 'undefined' || !Java.available) { updateSoundStatus('Android Java bridge unavailable.'); return; }
    // Prevent a previous clip from continuing while the next one is prepared.
    micPlaybackEnabled = false;
    stopLocalMonitorPlayback();
    updateSoundStatus('Preparing ' + name + ' in small batches…');
    Java.perform(() => {
      try {
        const File = Java.use('java.io.File');
        const wavFile = File.$new(SOUND_DIR + '/' + name);
        if (!wavFile.exists() || !wavFile.isFile()) throw new Error('WAV not found on Quest: ' + name);
        const fileSize = Number(wavFile.length());
        if (fileSize > MAX_WAV_BYTES) throw new Error('WAV exceeds 1 MB; use a shorter sound.');
        const raw = readWavBytes(wavFile);
        if (raw.length < 44 || raw[0] !== 82 || raw[1] !== 73 || raw[2] !== 70 || raw[3] !== 70 || raw[8] !== 87 || raw[9] !== 65 || raw[10] !== 86 || raw[11] !== 69) throw new Error('Not a valid RIFF/WAVE file');
        const u8 = (i: number) => { const v = Number(raw[i]); return v < 0 ? v + 256 : v; };
        const u16 = (i: number) => u8(i) | (u8(i + 1) << 8);
        const u32 = (i: number) => (u8(i) | (u8(i + 1) << 8) | (u8(i + 2) << 16) | (u8(i + 3) << 24)) >>> 0;
        let off = 12, format = 0, channels = 0, sampleRate = 0, bits = 0, blockAlign = 0, dataStart = -1, dataSize = 0;
        while (off + 8 <= raw.length) {
          const chunkSize = u32(off + 4);
          if (off + 8 + chunkSize > raw.length) throw new Error('Corrupt WAV chunk bounds');
          if (raw[off] === 102 && raw[off + 1] === 109 && raw[off + 2] === 116 && raw[off + 3] === 32) {
            if (chunkSize < 16) throw new Error('Invalid WAV format chunk');
            format = u16(off + 8); channels = u16(off + 10); sampleRate = u32(off + 12); blockAlign = u16(off + 20); bits = u16(off + 22);
          }
          if (raw[off] === 100 && raw[off + 1] === 97 && raw[off + 2] === 116 && raw[off + 3] === 97) { dataStart = off + 8; dataSize = chunkSize; break; }
          off += 8 + chunkSize + (chunkSize % 2);
        }
        if (format !== 1 || bits !== 16 || (channels !== 1 && channels !== 2) || sampleRate < 8000 || sampleRate > 96000 || blockAlign !== channels * 2 || dataStart < 0 || dataSize < blockAlign) {
          throw new Error('Use uncompressed PCM16 WAV (mono/stereo, 8–96 kHz).');
        }
        const frames = Math.floor(dataSize / blockAlign);
        if (frames < 1) throw new Error('WAV has no audio samples');
        const mono: number[] = new Array(frames);
        let peak = 0, sumSquares = 0;
        // Chunk 1: decode/downmix with a yield every 4096 frames.
        const decodeBatch = (from: number) => {
          const to = Math.min(frames, from + 4096);
          for (let f = from; f < to; f++) {
            const at = dataStart + f * blockAlign;
            const l0 = u8(at), l1 = u8(at + 1); let left = (l1 << 8) | l0; if (left >= 32768) left -= 65536;
            let sample = left;
            if (channels === 2) { const r0 = u8(at + 2), r1 = u8(at + 3); let right = (r1 << 8) | r0; if (right >= 32768) right -= 65536; sample = Math.round((left + right) / 2); }
            mono[f] = sample;
            const abs = Math.abs(sample); if (abs > peak) peak = abs;
            sumSquares += sample * sample;
          }
          if (to < frames) { setTimeout(() => decodeBatch(to), 0); return; }
          try { beginResample(); } catch (e) { failLoad(e); }
        };
        const failLoad = (e: any) => {
          micPlaybackEnabled = false; activeSoundName = null; micPlaybackSamples = null; micPlaybackCursor = 0;
          updateSoundStatus('Could not send ' + name + ': ' + e);
        };
        const beginResample = () => {
          if (peak < 1) throw new Error('WAV is silent');
          const rms = Math.sqrt(sumSquares / frames);
          const normGain = Math.min(MAX_NORMALIZE_GAIN, TARGET_RMS / Math.max(1, rms));
          const targetRate = micSampleRate || 48000;
          const outputFrames = Math.max(1, Math.floor(frames * targetRate / sampleRate));
          if (outputFrames > targetRate * MAX_PLAYBACK_SECONDS) throw new Error('Sound is longer than 10 seconds; trim it first.');
          const resampled: number[] = new Array(outputFrames);
          const resampleBatch = (from: number) => {
            const to = Math.min(outputFrames, from + 4096);
            for (let i = from; i < to; i++) {
              const srcPos = i * sampleRate / targetRate;
              const i0 = Math.min(frames - 1, Math.floor(srcPos));
              const i1 = Math.min(frames - 1, i0 + 1);
              const frac = srcPos - i0;
              const sourceSample = (mono[i0] + (mono[i1] - mono[i0]) * frac) * normGain;
              const abs = Math.abs(sourceSample);
              const limited = abs <= 28000 ? sourceSample : Math.sign(sourceSample) * (28000 + (abs - 28000) * 0.18);
              resampled[i] = clampPcm16(Math.round(limited));
            }
            if (to < outputFrames) { setTimeout(() => resampleBatch(to), 0); return; }
            try {
              startLocalMonitorPlayback(resampled, targetRate, name);
              micPlaybackEnabled = false;
              micPlaybackSamples = resampled;
              micPlaybackCursor = 0;
              activeSoundName = name;
              soundFinished = false;
              micPlaybackEnabled = true;
              const checkId = ++micPlaybackCheckId;
              const injectionBaseline = micInjectionSamples;
              const readBaseline = micReadCallbacks;
              updateSoundStatus('Playing locally + sending to voice chat: ' + name + '; checking mic capture…');
              if (soundInfoLabel) step('sound info label', () => soundInfoLabel!.method('set_text').invoke(Il2Cpp.string('Streaming locally • checking mic capture • one-shot')), null);
              setTimeout(() => {
                if (checkId !== micPlaybackCheckId) return;
                const injected = micInjectionSamples - injectionBaseline;
                if (injected > 0) {
                  const msg = 'Mixed ' + injected + ' mic samples; local playback is streaming.';
                  updateSoundStatus(msg);
                  if (soundInfoLabel) step('sound info label', () => soundInfoLabel!.method('set_text').invoke(Il2Cpp.string('Mic samples mixed • local stream active')), null);
                } else {
                  const readsDuringClip = micReadCallbacks - readBaseline;
                  const msg = readsDuringClip > 0 ? 'Mic reads seen but no samples mixed; check Frida log.' : 'No mic callbacks during clip; local playback may still work.';
                  updateSoundStatus(msg);
                  log('soundboard diagnostic: ' + msg);
                }
              }, 2500);
            } catch (e) { failLoad(e); }
          };
          resampleBatch(0);
        };
        decodeBatch(0);
      } catch (e) {
        micPlaybackEnabled = false; activeSoundName = null; micPlaybackSamples = null; micPlaybackCursor = 0;
        updateSoundStatus('Could not send ' + name + ': ' + e);
      }
    });
  }

  function stopSoundPlayback() {
    micPlaybackCheckId++;
    stopLocalMonitorPlayback();
    micPlaybackEnabled = false;
    const stopped = activeSoundName;
    activeSoundName = null;
    micPlaybackSamples = null;
    micPlaybackCursor = 0;
    soundFinished = false;
    updateSoundStatus(stopped ? 'Stopped: ' + stopped : 'Soundboard stopped.');
  }

  function refreshSoundFiles() {
    if (typeof Java === 'undefined' || !Java.available) {
      soundFiles = [];
      btns.forEach(b => { if (b.tab === 'Soundboard' && b.id.indexOf('sound_') === 0 && b.id !== 'sound_refresh' && b.id !== 'sound_info' && b.id !== 'sound_stop') refreshBtn(b); });
      updateSoundStatus('Cannot scan sounds: Android Java bridge unavailable.');
      return;
    }
    updateSoundStatus('Scanning Quest sound folder…');
    try {
      Java.perform(() => {
        const found: string[] = [];
        let listingError = '';
        try {
          const File = Java.use('java.io.File');
          const dir = File.$new(SOUND_DIR);
          if (!dir.exists()) throw new Error('Quest folder missing: ' + SOUND_DIR + '. Check launcher sync.');
          if (!dir.isDirectory()) throw new Error('Quest sound path is not a folder: ' + SOUND_DIR);
          const files = dir.listFiles();
          if (files === null) throw new Error('Android returned no directory listing.');
          for (let i = 0; i < files.length; i++) {
            try { const file = files[i]; if (file.isFile()) { const name = String(file.getName().toString()); if (/\.(wav|mp3)$/i.test(name)) found.push(name); } }
            catch (inner) { log('Could not inspect sound entry ' + i + ': ' + inner); }
          }
        } catch (e) { listingError = String(e); log('Soundboard scan failed at ' + SOUND_DIR + ': ' + listingError); }
        found.sort((a, b) => { const aw = /\.wav$/i.test(a), bw = /\.wav$/i.test(b); if (aw !== bw) return aw ? -1 : 1; const al = a.toLowerCase(), bl = b.toLowerCase(); return al < bl ? -1 : (al > bl ? 1 : 0); });
        log('soundboard scan path: ' + SOUND_DIR + '; raw audio matches=' + found.length);
        found.forEach((name, index) => log('soundboard file[' + index + ']: ' + name));
        soundFiles = found.slice(0, SOUND_SLOTS);
        btns.forEach(b => { if (b.tab === 'Soundboard' && b.id.indexOf('sound_') === 0 && b.id !== 'sound_refresh' && b.id !== 'sound_info' && b.id !== 'sound_stop') refreshBtn(b); });
        if (listingError) updateSoundStatus('Scan failed: ' + listingError);
        else if (found.length === 0) updateSoundStatus('Found 0 WAV/MP3 files at ' + SOUND_DIR + '. Check sync path and build marker in Frida log.');
        else updateSoundStatus('Found ' + found.length + ' WAV/MP3 file(s); showing ' + soundFiles.length + '. MP3 needs conversion to PCM16 WAV for VC.');
      });
    } catch (e) { updateSoundStatus('Could not start sound scan: ' + e); }
  }

  // ---------- build ----------
  function destroyOld() {
    step('destroy old', () => {
      const old = need('UnityEngine.GameObject').method('Find', 1).invoke(Il2Cpp.string('PVTX_MENU_ROOT')) as Il2Cpp.Object;
      if (old && !old.isNull()) { need('UnityEngine.Object').method('Destroy', 1).invoke(old); log('removed stale PVTX_MENU_ROOT'); }
    }, null);
  }
  function build() {
    destroyOld();
    root = mk('PVTX_MENU_ROOT', null);
    // Canvas: world space (renderMode 2). Camera is assigned at open time if available.
    canvasObj = root.go.method('AddComponent', 1).invoke(need('UnityEngine.Canvas').type.object) as Il2Cpp.Object;
    canvasObj.method('set_renderMode').invoke(2);
    step('canvas sortingOrder', () => canvasObj!.method('set_sortingOrder').invoke(5000), null);
    step('canvas overrideSorting', () => canvasObj!.method('set_overrideSorting').invoke(true), null);
    // CanvasScaler helps some Quest builds render UI at consistent size
    step('canvas scaler', () => {
      const sc = root!.go.method('AddComponent', 1).invoke(need('UnityEngine.UI.CanvasScaler').type.object) as Il2Cpp.Object;
      sc.method('set_dynamicPixelsPerUnit').invoke(10);
      sc.method('set_referencePixelsPerUnit').invoke(100);
    }, null);
    place(root, 0, 0, 640, 440);
    root.tf.method('set_localScale').invoke(v3(0.0012, 0.0012, 0.0012));
    const bgN = mk('bg', root.tf); place(bgN, 0, 0, 640, 440); img(bgN, T.bg);
    const hdr = mk('hdr', root.tf); place(hdr, 0, 195, 640, 50); img(hdr, T.panel);
    label(root.tf, 'PVTX | TAG BEFORE DAWN', 32, 0, 195, 600, 50);

    const tabs = ['Movement', 'Fly', 'ESP', 'TP', 'Soundboard', 'Settings'];
    tabs.forEach((t, i) => {
      const n = mk('tab_' + t, root!.tf); place(n, 0, 0, 1, 1); tabRoots[t] = n;
      addBtn('*', 'tab_' + t, -260 + i * 104, 140, 100, 44, () => t, () => setTab(t), () => cfg.tab === t);
    });
    const rows = (tab: string, y: number, name: string, get: () => string, dec: () => void, inc: () => void) => {
      label(tabRoots[tab].tf, name, 28, -170, y, 260, 50, T.dim);
      addBtn(tab, name + '-', 0, y, 70, 50, () => '-', dec);
      addBtn(tab, name + '+', 175, y, 70, 50, () => '+', inc);
      const v = label(tabRoots[tab].tf, get(), 28, 90, y, 100, 50); valueLabels.push({ t: v, get });
    };
    // Speed: no upper limit
    rows('Movement', 60, 'Speed', () => state.speed >= 100 ? state.speed.toFixed(0) + 'x' : state.speed.toFixed(1) + 'x',
      () => { state.speed = Math.max(0.5, state.speed - (state.speed > 10 ? 5 : state.speed > 5 ? 1 : 0.5)); applyMove(); },
      () => { state.speed = state.speed + (state.speed >= 20 ? 10 : state.speed >= 10 ? 5 : state.speed >= 5 ? 1 : 0.5); applyMove(); });
    rows('Movement', -5, 'Jump', () => state.jump.toFixed(1) + 'x', () => { state.jump = Math.max(0.5, state.jump - 0.1); applyMove(); }, () => { state.jump = Math.min(10.0, state.jump + 0.1); applyMove(); });
    addBtn('Movement', 'gripplat', -150, -75, 280, 48, () => 'Grip Platforms: ' + (state.gripPlatforms ? 'ON' : 'OFF'), () => { state.gripPlatforms = !state.gripPlatforms; if (!state.gripPlatforms) destroyGripPlatforms(); log('grip platforms=' + state.gripPlatforms); }, () => state.gripPlatforms);
    addBtn('Movement', 'stopvel', 150, -75, 280, 48, () => 'Stop Velocity', stopVelocity);
    infoText = label(tabRoots['Movement'].tf, 'Hold L/R Grip to spawn platforms under hands (climb).', 20, 0, -140, 560, 36, T.dim);
    addBtn('Fly', 'fly', -150, 60, 280, 54, () => 'Fly: ' + (state.fly ? 'ON' : 'OFF'), () => {
      state.fly = !state.fly; applyPhysics();
      if (state.fly) {
        setPlayerCollisions(false);
        stripCeilingsAndBarriers();
        breakHeightClamp();
        lastCeilingStrip = tickCount;
        log('FLY ON — collisions off + ceilings stripped');
      } else {
        setPlayerCollisions(true);
        log('FLY OFF — collisions restored');
      }
    }, () => state.fly);
    addBtn('Fly', 'grav', 150, 60, 280, 54, () => 'Gravity: ' + (state.grav ? 'ON' : 'OFF'), () => { state.grav = !state.grav; applyPhysics(); }, () => state.grav);
    addBtn('Fly', 'noclip', 0, -5, 300, 54, () => 'Noclip: ' + (state.noclip ? 'ON' : 'OFF'), () => { state.noclip = !state.noclip; applyNoclip(); }, () => state.noclip);
    rows('Fly', -70, 'Fly Spd', () => state.flySpeed.toFixed(0) + ' m/s', () => { state.flySpeed = Math.max(1, state.flySpeed - 1); }, () => { state.flySpeed = Math.min(15, state.flySpeed + 1); });
    label(tabRoots['Fly'].tf, 'Fly: menu CLOSED, hold R-Trigger = move where you LOOK (head). Release = hover.', 20, 0, -135, 600, 40, T.dim);

    // ---- ESP tab ----
    addBtn('ESP', 'esp_killer', -150, 60, 280, 50, () => 'Killer ESP: ' + (state.espKiller ? 'ON' : 'OFF'), () => { state.espKiller = !state.espKiller; log('Killer ESP=' + state.espKiller); }, () => state.espKiller);
    addBtn('ESP', 'esp_surv', 150, 60, 280, 50, () => 'Survivor ESP: ' + (state.espSurvivor ? 'ON' : 'OFF'), () => { state.espSurvivor = !state.espSurvivor; log('Survivor ESP=' + state.espSurvivor); }, () => state.espSurvivor);
    addBtn('ESP', 'esp_all', -150, -5, 280, 50, () => 'All Players ESP: ' + (state.espAll ? 'ON' : 'OFF'), () => { state.espAll = !state.espAll; }, () => state.espAll);
    addBtn('ESP', 'esp_dist', 150, -5, 280, 50, () => 'Show Distance: ' + (state.espDist ? 'ON' : 'OFF'), () => { state.espDist = !state.espDist; }, () => state.espDist);
    addBtn('ESP', 'esp_refresh', 0, -70, 300, 44, () => 'Refresh Player Scan', () => { scanRoomPlayers(true); refreshTpPage(); });
    espStatusLabel = label(tabRoots['ESP'].tf, 'Red = Killer  |  Cyan = Survivor', 22, 0, -130, 560, 40, T.dim);

    // ---- TP tab: list players, tap to teleport ----
    tpPageLabel = label(tabRoots['TP'].tf, 'Players in room', 22, 0, 95, 500, 30, T.dim);
    for (let i = 0; i < TP_PER_PAGE; i++) {
      const slot = i;
      const y = 55 - i * 36;
      addBtn('TP', 'tpslot_' + i, 0, y, 560, 32,
        () => {
          const idx = cfg.tpPage * TP_PER_PAGE + slot;
          if (idx >= roomPlayers.length) return '';
          const p = roomPlayers[idx];
          const role = p.role === 'killer' ? '[KILLER]' : p.role === 'survivor' ? '[SURV]' : '[?]';
          return role + ' ' + p.name + (state.espDist && p.dist >= 0 ? '  ' + p.dist.toFixed(1) + 'm' : '');
        },
        () => {
          const idx = cfg.tpPage * TP_PER_PAGE + slot;
          if (idx >= roomPlayers.length) return;
          teleportToPlayer(roomPlayers[idx]);
        },
        () => {
          const idx = cfg.tpPage * TP_PER_PAGE + slot;
          return idx < roomPlayers.length && roomPlayers[idx].role === 'killer';
        });
    }
    addBtn('TP', 'tp_prev', -150, -165, 140, 40, () => '< Prev', () => {
      if (cfg.tpPage > 0) { cfg.tpPage--; refreshTpPage(); }
    });
    addBtn('TP', 'tp_next', 150, -165, 140, 40, () => 'Next >', () => {
      const maxP = Math.max(1, Math.ceil(roomPlayers.length / TP_PER_PAGE));
      if (cfg.tpPage < maxP - 1) { cfg.tpPage++; refreshTpPage(); }
    });
    addBtn('TP', 'tp_scan', 0, -165, 120, 40, () => 'Scan', () => { scanRoomPlayers(true); refreshTpPage(); });

    // Identify likely IL2CPP voice-capture SDK classes so the next fix can target the real path.
    try {
      const voiceCandidates: string[] = [];
      for (const assembly of Il2Cpp.domain.assemblies) {
        try {
          const assemblyName = String(assembly.name);
          if (/(photon|voice|dissonance|vivox|webrtc|audio)/i.test(assemblyName)) {
            voiceCandidates.push('ASSEMBLY ' + assemblyName);
          }
          for (const klass of assembly.image.classes) {
            const fullName = String(klass.fullName || klass.name);
            if (/(Photon.*Voice|Voice.*(Recorder|Connection|Client|Audio|Mic)|Dissonance|Vivox|MicWrapper|Microphone|AudioIn.*(Mic|Voice))/i.test(fullName)) {
              voiceCandidates.push(assemblyName + '!' + fullName);
              if (voiceCandidates.length >= 70) break;
            }
          }
        } catch (_) {}
        if (voiceCandidates.length >= 70) break;
      }
      log('voice/audio assembly scan candidates=' + voiceCandidates.length);
      for (let i = 0; i < voiceCandidates.length; i++) log('VOICE-CANDIDATE ' + voiceCandidates[i]);
      if (voiceCandidates.length === 0) log('VOICE-CANDIDATE scan found no matching loaded IL2CPP class names.');
    } catch (scanError) { log('voice/audio class scan failed: ' + scanError); }

    // ---- Soundboard tab ----
    soundStatusLabel = label(tabRoots['Soundboard'].tf, 'VC input: PCM16 WAV. MP3 files are listed but must be converted before VC injection.', 18, 0, 105, 590, 34, T.dim);
    for (let i = 0; i < SOUND_SLOTS; i++) {
      const slot = i;
      addBtn('Soundboard', 'sound_' + i, 0, 65 - i * 32, 560, 29,
        () => soundFiles[slot] || '(empty slot ' + (slot + 1) + ')',
        () => { if (!soundFiles[slot]) { updateSoundStatus('Slot ' + (slot + 1) + ' is empty; press Refresh Sounds.'); return; } loadWavForMic(soundFiles[slot]); });
    }
    addBtn('Soundboard', 'sound_refresh', -145, -185, 270, 38, () => 'Refresh Sounds', refreshSoundFiles);
    addBtn('Soundboard', 'sound_stop', 145, -185, 270, 38, () => 'Stop Sound', stopSoundPlayback);
    soundInfoLabel = label(tabRoots['Soundboard'].tf, 'PCM16 WAV required • MP3 listed for conversion • VC path unverified', 16, 0, -220, 560, 26, T.dim);

    rows('Settings', 60, 'Scale', () => cfg.scale.toFixed(1), () => { cfg.scale = Math.max(0.5, cfg.scale - 0.1); applyScale(); }, () => { cfg.scale = Math.min(2.0, cfg.scale + 0.1); applyScale(); });
    rows('Settings', -5, 'Distance', () => cfg.distance.toFixed(1) + 'm', () => { cfg.distance = Math.max(0.5, cfg.distance - 0.1); }, () => { cfg.distance = Math.min(2.0, cfg.distance + 0.1); });
    addBtn('Settings', 'follow', -150, -75, 280, 54, () => 'Follow Head: ' + (cfg.follow ? 'ON' : 'OFF'), () => { cfg.follow = !cfg.follow; }, () => cfg.follow);
    addBtn('Settings', 'diag', 150, -75, 280, 54, () => 'Diag Log: ' + (cfg.diag ? 'ON' : 'OFF'), () => { cfg.diag = !cfg.diag; }, () => cfg.diag);
    label(root.tf, 'Open/close: hold L-Grip + L-Trigger. Point right hand, pull R-Trigger.', 20, 0, -205, 620, 30, T.dim);

    cursor = mk('cursor', root.tf); place(cursor, 0, 0, 14, 14); img(cursor, T.cursor);
    step('cursor off', () => cursor!.go.method('SetActive').invoke(false), null);
    installMicCaptureHook();
    refreshSoundFiles();
    setTab(cfg.tab);
    step('root off', () => root!.go.method('SetActive').invoke(false), null);
    builtOnce = true;
    log('panel BUILT (hidden). Not visually confirmed - needs headset test.');
    if (!K('GTPlayer')) {
      log('GTPlayer not found - scanning for candidate classes (send these lines back):');
      scanLog('player'); scanLog('controller'); scanLog('inputprocessor|rawinput');
    }
  }
  const valueLabels: { t: Il2Cpp.Object; get: () => string }[] = [];
  let playerInfo: Il2Cpp.Object | null = null;
  let espStatusLabel: Il2Cpp.Object | null = null;
  let tpPageLabel: Il2Cpp.Object | null = null;

  interface RoomPlayer {
    obj: Il2Cpp.Object;
    name: string;
    role: 'killer' | 'survivor' | 'unknown';
    pos: [number, number, number];
    dist: number;
    tf: Il2Cpp.Object | null;
  }
  let roomPlayers: RoomPlayer[] = [];
  // ESP world labels keyed by a stable id string
  const espLabels: { [id: string]: { go: Il2Cpp.Object; tmp: Il2Cpp.Object } } = {};
  let lastPlayerScan = 0;

  function refreshTpPage() {
    const total = Math.max(1, Math.ceil(roomPlayers.length / TP_PER_PAGE) || 1);
    if (tpPageLabel) {
      step('tp page label', () => tpPageLabel!.method('set_text').invoke(
        Il2Cpp.string('Players ' + (cfg.tpPage + 1) + '/' + total + '  (' + roomPlayers.length + ' in room)')
      ), null);
    }
    if (espStatusLabel) {
      const killers = roomPlayers.filter(p => p.role === 'killer').length;
      const survs = roomPlayers.filter(p => p.role === 'survivor').length;
      step('esp status', () => espStatusLabel!.method('set_text').invoke(
        Il2Cpp.string('Killers: ' + killers + '  Survivors: ' + survs + '  Unknown: ' + (roomPlayers.length - killers - survs) + '  |  Red=Killer Cyan=Surv')
      ), null);
    }
    btns.forEach(b => { if (b.tab === 'TP' && b.id.indexOf('tpslot_') === 0) refreshBtn(b); });
  }

  function playerTransform(): Il2Cpp.Object | null {
    return step('player tf', () => {
      if (!player) return null;
      const go = player.method('get_gameObject').invoke() as Il2Cpp.Object;
      if (!go || go.isNull()) return null;
      return go.method('get_transform').invoke() as Il2Cpp.Object;
    }, null);
  }


  function detectRole(obj: Il2Cpp.Object): 'killer' | 'survivor' | 'unknown' {
    const boolFields = [
      'isKiller', 'IsKiller', 'is_killer', 'killer', 'isMurderer', 'IsMurderer',
      'isHunter', 'IsHunter', 'isSeeker', 'IsSeeker', 'isTagger', 'IsTagger',
    ];
    for (const f of boolFields) {
      try {
        const v = obj.field(f).value;
        if (v === true || v === 1) return 'killer';
        if (v === false || v === 0) return 'survivor';
      } catch (_) {}
    }
    const roleFields = ['role', 'Role', 'playerRole', 'PlayerRole', 'team', 'Team', 'faction', 'Faction', 'characterType', 'CharacterType', 'playerType', 'type'];
    for (const f of roleFields) {
      try {
        const v = obj.field(f).value;
        const s = String(v).toLowerCase();
        if (/kill|hunter|seeker|murder|tagger|beast|monster/.test(s)) return 'killer';
        if (/surv|human|civilian|victim|prey|innocent/.test(s)) return 'survivor';
        const n = Number(v);
        if (!isNaN(n)) {
          // common: 0=survivor 1=killer or vice versa — log once
          if (n === 1) return 'killer';
          if (n === 0) return 'survivor';
        }
      } catch (_) {}
    }
    // Nested controller / data object
    for (const nest of ['data', 'Data', 'info', 'Info', 'state', 'State', 'netData']) {
      try {
        const nested = obj.field(nest).value as Il2Cpp.Object;
        if (nested && !nested.isNull()) {
          const r = detectRole(nested);
          if (r !== 'unknown') return r;
        }
      } catch (_) {}
    }
    return 'unknown';
  }

  function readPlayerName(obj: Il2Cpp.Object): string {
    const fields = ['playerName', 'PlayerName', 'displayName', 'DisplayName', 'nickName', 'NickName', 'name', 'Name', 'username', 'userName'];
    for (const f of fields) {
      try {
        const v = obj.field(f).value;
        if (v != null && String(v).length > 0 && String(v) !== 'null') return String(v).substring(0, 24);
      } catch (_) {}
    }
    try {
      const go = obj.method('get_gameObject').invoke() as Il2Cpp.Object;
      if (go && !go.isNull()) return String(go.method('get_name').invoke()).substring(0, 24);
    } catch (_) {}
    return 'Player';
  }

  function getObjTransform(obj: Il2Cpp.Object): Il2Cpp.Object | null {
    return step('obj tf', () => {
      try {
        const go = obj.method('get_gameObject').invoke() as Il2Cpp.Object;
        if (go && !go.isNull()) return go.method('get_transform').invoke() as Il2Cpp.Object;
      } catch (_) {}
      try { return obj.method('get_transform').invoke() as Il2Cpp.Object; } catch (_) {}
      return null;
    }, null);
  }

  function scanRoomPlayers(forceLog = false) {
    const out: RoomPlayer[] = [];
    const classNames = ['GTPlayer', 'Cydream.GTPlayer', 'Player', 'Cydream.Player', 'VRPlayer', 'Cydream.VRPlayer'];
    let klass: Il2Cpp.Class | null = null;
    for (const n of classNames) { klass = K(n); if (klass) break; }
    if (!klass) {
      if (forceLog) log('scanRoomPlayers: no player class found');
      roomPlayers = out;
      return;
    }
    // Prefer FindObjectsOfType
    step('scan players', () => {
      try {
        const arr = need('UnityEngine.Object').method('FindObjectsOfType', 1).invoke(klass!.type.object) as any;
        if (!arr) return;
        let myPos: [number, number, number] = [0, 0, 0];
        const myTf = playerTransform();
        if (myTf) myPos = rd(myTf.method('get_position').invoke() as any);
        for (const item of arr) {
          try {
            const obj = item as Il2Cpp.Object;
            if (!obj || obj.isNull()) continue;
            // Skip local player
            if (player && obj.handle && player.handle && obj.handle.equals(player.handle)) continue;
            const tf = getObjTransform(obj);
            let pos: [number, number, number] = [0, 0, 0];
            if (tf) pos = rd(tf.method('get_position').invoke() as any);
            const dx = pos[0] - myPos[0], dy = pos[1] - myPos[1], dz = pos[2] - myPos[2];
            const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
            const role = detectRole(obj);
            const name = readPlayerName(obj);
            out.push({ obj, name, role, pos, dist, tf });
          } catch (_) {}
        }
      } catch (e) {
        if (forceLog) log('FindObjectsOfType players failed: ' + e);
      }
    }, null);

    // Fallback: Il2Cpp.gc.choose if available
    if (out.length === 0) {
      step('gc choose players', () => {
        try {
          const choose = (Il2Cpp as any).gc && (Il2Cpp as any).gc.choose;
          if (!choose) return;
          const arr = choose(klass);
          for (const obj of arr) {
            try {
              if (!obj || obj.isNull()) continue;
              if (player && obj.handle && player.handle && obj.handle.equals(player.handle)) continue;
              const tf = getObjTransform(obj);
              let pos: [number, number, number] = [0, 0, 0];
              if (tf) pos = rd(tf.method('get_position').invoke() as any);
              out.push({ obj, name: readPlayerName(obj), role: detectRole(obj), pos, dist: -1, tf });
            } catch (_) {}
          }
        } catch (_) {}
      }, null);
    }

    roomPlayers = out;
    if (forceLog || out.length > 0) {
      log('room players: ' + out.length + ' (killers=' + out.filter(p => p.role === 'killer').length +
        ' survivors=' + out.filter(p => p.role === 'survivor').length + ')');
    }
  }

  function teleportToPlayer(rp: RoomPlayer) {
    if (!rp) return;
    const tf = playerTransform();
    if (!tf) { log('TP failed: no local player'); return; }
    let pos = rp.pos;
    if (rp.tf) {
      try { pos = rd(rp.tf.method('get_position').invoke() as any); } catch (_) {}
    }
    step('tp to player', () => {
      // Stand slightly beside them
      tf.method('set_position').invoke(v3(pos[0] + 0.5, pos[1] + 0.2, pos[2] + 0.5));
      const rb = rigidBody();
      if (rb) rb.method('set_velocity').invoke(v3(0, 0, 0));
      log('TP → ' + rp.name + ' (' + rp.role + ') @ ' + pos.map(x => x.toFixed(1)).join(','));
    }, null);
  }

  function ensureEspLabel(id: string): { go: Il2Cpp.Object; tmp: Il2Cpp.Object } | null {
    if (espLabels[id]) return espLabels[id];
    return step('mk esp ' + id, () => {
      const go = need('UnityEngine.GameObject').new();
      go.method('.ctor', 1).invoke(Il2Cpp.string('PVTX_ESP_' + id));
      const tmp = go.method('AddComponent', 1).invoke(need('TMPro.TextMeshPro').type.object) as Il2Cpp.Object;
      tmp.method('set_fontSize').invoke(4);
      tmp.method('set_alignment').invoke(514);
      try { tmp.method('set_enableWordWrapping').invoke(false); } catch (_) {}
      espLabels[id] = { go, tmp };
      return espLabels[id];
    }, null);
  }

  function clearEspLabels() {
    for (const id of Object.keys(espLabels)) {
      try {
        const e = espLabels[id];
        if (e && e.go && !e.go.isNull()) need('UnityEngine.Object').method('Destroy', 1).invoke(e.go);
      } catch (_) {}
      delete espLabels[id];
    }
  }

  function updateEsp() {
    if (!state.espKiller && !state.espSurvivor && !state.espAll) {
      // Hide all
      for (const id of Object.keys(espLabels)) {
        try { espLabels[id].go.method('SetActive').invoke(false); } catch (_) {}
      }
      return;
    }
    const seen: { [id: string]: boolean } = {};
    const head = headTransform();
    let headPos: [number, number, number] = [0, 1.5, 0];
    if (head) {
      try { headPos = rd(head.method('get_position').invoke() as any); } catch (_) {}
    }
    for (let i = 0; i < roomPlayers.length; i++) {
      const rp = roomPlayers[i];
      const show =
        state.espAll ||
        (state.espKiller && rp.role === 'killer') ||
        (state.espSurvivor && rp.role === 'survivor') ||
        (state.espKiller && state.espSurvivor); // both on → show unknown too if either on? only known roles
      if (!show && !(state.espKiller && state.espSurvivor && rp.role === 'unknown' && state.espAll)) {
        if (!(state.espKiller || state.espSurvivor || state.espAll)) continue;
        if (rp.role === 'unknown' && !state.espAll) continue;
        if (rp.role === 'killer' && !state.espKiller && !state.espAll) continue;
        if (rp.role === 'survivor' && !state.espSurvivor && !state.espAll) continue;
      }
      const want =
        state.espAll ||
        (rp.role === 'killer' && state.espKiller) ||
        (rp.role === 'survivor' && state.espSurvivor);
      if (!want) continue;

      const id = 'p' + i + '_' + rp.name.replace(/[^a-zA-Z0-9]/g, '').substring(0, 12);
      seen[id] = true;
      const lab = ensureEspLabel(id);
      if (!lab) continue;
      step('esp upd ' + id, () => {
        lab.go.method('SetActive').invoke(true);
        let pos = rp.pos;
        if (rp.tf) {
          try { pos = rd(rp.tf.method('get_position').invoke() as any); } catch (_) {}
        }
        const tf = lab.go.method('get_transform').invoke() as Il2Cpp.Object;
        tf.method('set_position').invoke(v3(pos[0], pos[1] + 1.8, pos[2]));
        // Billboard toward head
        if (head) {
          try {
            const look: any = need('UnityEngine.Quaternion').method('LookRotation', 1).invoke(
              v3(headPos[0] - pos[0], 0, headPos[2] - pos[2])
            );
            tf.method('set_rotation').invoke(look);
          } catch (_) {}
        }
        const roleTag = rp.role === 'killer' ? 'KILLER' : rp.role === 'survivor' ? 'SURVIVOR' : 'PLAYER';
        let text = roleTag + '\n' + rp.name;
        if (state.espDist) {
          const dx = pos[0] - headPos[0], dy = pos[1] - headPos[1], dz = pos[2] - headPos[2];
          const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
          text += '\n' + dist.toFixed(1) + 'm';
        }
        lab.tmp.method('set_text').invoke(Il2Cpp.string(text));
        const cv = rp.role === 'killer' ? [1, 0.15, 0.15, 1] : rp.role === 'survivor' ? [0.2, 0.95, 1, 1] : [1, 1, 0.4, 1];
        try {
          const cobj = need('UnityEngine.Color').new();
          cobj.method('.ctor', 4).invoke(cv[0], cv[1], cv[2], cv[3]);
          lab.tmp.method('set_color').invoke(cobj.unbox());
        } catch (_) {}
      }, null);
    }
    // Hide unused
    for (const id of Object.keys(espLabels)) {
      if (!seen[id]) {
        try { espLabels[id].go.method('SetActive').invoke(false); } catch (_) {}
      }
    }
  }

  function modTick() {
    if (soundFinished) { soundFinished = false; const finished = activeSoundName; activeSoundName = null; micPlaybackSamples = null; micPlaybackCursor = 0; updateSoundStatus(finished ? 'Sent to VC: ' + finished : 'Sound finished.'); }
    // Re-scan players every ~2s
    if (tickCount - lastPlayerScan > 120) {
      lastPlayerScan = tickCount;
      scanRoomPlayers(false);
      if (cfg.tab === 'TP' || cfg.tab === 'ESP') refreshTpPage();
    }
    // Update ESP every few frames
    if ((state.espKiller || state.espSurvivor || state.espAll) && tickCount % 3 === 0) {
      updateEsp();
    }
  }

  function setTab(t: string) {
    cfg.tab = t;
    for (const k in tabRoots) step('tab ' + k, () => tabRoots[k].go.method('SetActive').invoke(k === t), null);
    if (t === 'TP' || t === 'ESP') { scanRoomPlayers(true); refreshTpPage(); }
    if (t === 'Soundboard') refreshSoundFiles();
    btns.forEach(refreshBtn);
  }
  function applyScale() { step('scale', () => { const s = 0.001 * cfg.scale; root!.tf.method('set_localScale').invoke(v3(s, s, s)); }, null); }

  // ---------- movement (fields confirmed in dump.cs: GTPlayer.speedMul, GTController.jumpMultiplier, playerRigidBody) ----------
  let baseJump: number | null = null;
  function applyMove() {
    if (!player || !ctrl) { if (infoText) infoText.method('set_text').invoke(Il2Cpp.string('Waiting for local player...')); return; }
    step('speedMul', () => { player!.field('speedMul').value = state.speed; }, null);
    step('jumpMultiplier', () => {
      if (baseJump === null) baseJump = Number(ctrl!.field('jumpMultiplier').value);
      ctrl!.field('jumpMultiplier').value = baseJump * state.jump;
    }, null);
  }
  function stopVelocity() {
    if (!ctrl) return;
    step('stop velocity', () => {
      const rb = ctrl!.field('playerRigidBody').value as Il2Cpp.Object;
      rb.method('set_velocity').invoke(v3(0, 0, 0));
    }, null);
  }

  // ---------- fly / gravity / noclip (UNTESTED) ----------
  function rigidBody(): Il2Cpp.Object | null {
    return step('rb', () => { const rb = ctrl!.field('playerRigidBody').value as Il2Cpp.Object; return rb && !rb.isNull() ? rb : null; }, null);
  }
  function applyPhysics() {
    if (!ctrl) return;
    const rb = rigidBody(); if (!rb) return;
    const gravityOn = state.grav && !state.fly;
    step('useGravity', () => rb.method('set_useGravity').invoke(gravityOn), null);
    // While flying/noclip: no physical collisions so barriers can't stop you
    if (state.fly || state.noclip) setPlayerCollisions(false);
    else setPlayerCollisions(true);
    if (!state.fly && !state.grav) step('zero vel (no grav)', () => rb.method('set_velocity').invoke(v3(0, 0, 0)), null);
    log('physics: fly=' + state.fly + ' gravity=' + gravityOn + ' collisions=' + !(state.fly || state.noclip));
  }
  function applyNoclip() {
    if (!ctrl) return;
    step('noclip', () => {
      const rb = rigidBody(); if (!rb) return;
      const go = rb.method('get_gameObject').invoke() as Il2Cpp.Object;
      const arr = go.method('GetComponentsInChildren', 2).invoke(need('UnityEngine.Collider').type.object, true) as any;
      let n = 0;
      for (const c of arr) { (c as Il2Cpp.Object).method('set_enabled').invoke(!state.noclip); n++; }
      log('noclip=' + state.noclip + ' (' + n + ' colliders toggled)');
    }, null);
  }
  function flyStep(trig: boolean) {
    if (!state.fly || !ctrl) return;
    step('fly', () => {
      const rb = rigidBody(); if (!rb) return;
      // Every frame while flying: ignore world collisions entirely
      try { rb.method('set_useGravity').invoke(false); } catch (_) {}
      try { rb.method('set_constraints').invoke(0); } catch (_) {}
      try { rb.method('set_detectCollisions').invoke(false); } catch (_) {}
      if (trig) {
        let d: [number, number, number] | null = null;
        const head = headTransform();
        if (head) d = rd(head.method('get_forward').invoke() as any);
        if (!d) {
          const hand = ctrl!.field('rightHandTransform').value as Il2Cpp.Object;
          d = rd(hand.method('get_forward').invoke() as any);
        }
        const len = Math.sqrt(d[0]*d[0] + d[1]*d[1] + d[2]*d[2]) || 1;
        const s = state.flySpeed / len;
        const vx = d[0] * s, vy = d[1] * s, vz = d[2] * s;
        // Velocity for physics systems that still read it
        try { rb.method('set_velocity').invoke(v3(vx, vy, vz)); } catch (_) {}
        // Primary movement: direct transform — bypasses all colliders
        const tf = playerTransform();
        if (tf) {
          const p = rd(tf.method('get_position').invoke() as any);
          const dt = 0.02; // ~50Hz effective step
          tf.method('set_position').invoke(v3(p[0] + vx * dt, p[1] + vy * dt, p[2] + vz * dt));
        }
      } else {
        try { rb.method('set_velocity').invoke(v3(0, 0, 0)); } catch (_) {}
      }
    }, null);
  }

  // ---------- grip platforms (hold grip → solid pad under that hand) ----------
  let leftPlat: Il2Cpp.Object | null = null, rightPlat: Il2Cpp.Object | null = null;
  const PLAT_SIZE: [number, number, number] = [0.55, 0.06, 0.55]; // width, thickness, depth
  const PLAT_Y_OFFSET = -0.08; // slightly below hand so palm sits on surface

  function createPlatform(name: string): Il2Cpp.Object | null {
    return step('create plat ' + name, () => {
      // Prefer CreatePrimitive(Cube=3) so it has MeshRenderer + BoxCollider
      let go: Il2Cpp.Object | null = null;
      try {
        go = need('UnityEngine.GameObject').method('CreatePrimitive', 1).invoke(3) as Il2Cpp.Object;
      } catch (_) {
        go = need('UnityEngine.GameObject').new();
        go.method('.ctor', 1).invoke(Il2Cpp.string(name));
        go.method('AddComponent', 1).invoke(need('UnityEngine.BoxCollider').type.object);
      }
      if (!go || go.isNull()) return null;
      go.method('set_name').invoke(Il2Cpp.string(name));
      const tf = go.method('get_transform').invoke() as Il2Cpp.Object;
      tf.method('set_localScale').invoke(v3(PLAT_SIZE[0], PLAT_SIZE[1], PLAT_SIZE[2]));
      // Make sure collider is enabled and not a trigger
      try {
        const col = go.method('GetComponent', 1).invoke(need('UnityEngine.BoxCollider').type.object) as Il2Cpp.Object;
        if (col && !col.isNull()) {
          col.method('set_enabled').invoke(true);
          col.method('set_isTrigger').invoke(false);
        }
      } catch (_) {}
      // Tint material if possible
      try {
        const rend = go.method('GetComponent', 1).invoke(need('UnityEngine.MeshRenderer').type.object) as Il2Cpp.Object;
        if (rend && !rend.isNull()) {
          const mat = rend.method('get_material').invoke() as Il2Cpp.Object;
          if (mat && !mat.isNull()) mat.method('set_color').invoke(col(0.35, 0.55, 1.0, 0.85));
        }
      } catch (_) {}
      return go;
    }, null);
  }

  function destroyGripPlatforms() {
    step('destroy plats', () => {
      for (const p of [leftPlat, rightPlat]) {
        if (p && !p.isNull()) need('UnityEngine.Object').method('Destroy', 1).invoke(p);
      }
      leftPlat = null; rightPlat = null;
    try { clearEspLabels(); } catch (_) {}
    }, null);
  }

  function handTf(side: 'left' | 'right'): Il2Cpp.Object | null {
    if (!ctrl) return null;
    const names = side === 'left'
      ? ['leftHandTransform', 'LeftHandTransform', 'leftHand', 'handLeft']
      : ['rightHandTransform', 'RightHandTransform', 'rightHand', 'handRight'];
    for (const n of names) {
      const t = step('hand ' + n, () => {
        try {
          const v = ctrl!.field(n).value as Il2Cpp.Object;
          return v && !v.isNull() ? v : null;
        } catch (_) { return null; }
      }, null);
      if (t) return t;
    }
    return null;
  }

  function updateOnePlatform(side: 'left' | 'right', gripped: boolean) {
    let plat = side === 'left' ? leftPlat : rightPlat;
    if (!gripped || !state.gripPlatforms) {
      if (plat && !plat.isNull()) {
        step('hide plat ' + side, () => plat!.method('SetActive').invoke(false), null);
      }
      return;
    }
    const hand = handTf(side);
    if (!hand) return;
    if (!plat || plat.isNull()) {
      plat = createPlatform('PVTX_GRIP_PLAT_' + side);
      if (side === 'left') leftPlat = plat; else rightPlat = plat;
      if (!plat) return;
    }
    step('place plat ' + side, () => {
      plat!.method('SetActive').invoke(true);
      const tf = plat!.method('get_transform').invoke() as Il2Cpp.Object;
      const hp = rd(hand.method('get_position').invoke() as any);
      // Keep platform upright (world-aligned), centered under hand
      tf.method('set_position').invoke(v3(hp[0], hp[1] + PLAT_Y_OFFSET, hp[2]));
      tf.method('set_rotation').invoke(need('UnityEngine.Quaternion').field('identity').value);
      tf.method('set_localScale').invoke(v3(PLAT_SIZE[0], PLAT_SIZE[1], PLAT_SIZE[2]));
    }, null);
  }

  function gripPlatformStep() {
    if (!ctrl || !inputP) return;
    if (!state.gripPlatforms) {
      if (leftPlat || rightPlat) destroyGripPlatforms();
      return;
    }
    const lg = Boolean(step('lgrip', () => inputP!.field('leftGripPressed').value, false));
    const rg = Boolean(step('rgrip', () => {
      try { return inputP!.field('rightGripPressed').value; } catch (_) {
        try { return inputP!.field('rightGrip').value; } catch (_) { return false; }
      }
    }, false));
    updateOnePlatform('left', lg);
    updateOnePlatform('right', rg);
  }

  // ---------- open/close/placement ----------
  function headTransform(): Il2Cpp.Object | null {
    if (ctrl) { const h = step('headCamera', () => (ctrl!.field('headCamera').value as Il2Cpp.Object).method('get_transform').invoke() as Il2Cpp.Object, null); if (h) return h; }
    return step('Camera.main', () => (need('UnityEngine.Camera').method('get_main').invoke() as Il2Cpp.Object).method('get_transform').invoke() as Il2Cpp.Object, null);
  }
  function assignCanvasCamera() {
    if (!canvasObj) return;
    step('canvas camera', () => {
      let cam: Il2Cpp.Object | null = null;
      if (ctrl) {
        try {
          const hc = ctrl!.field('headCamera').value as Il2Cpp.Object;
          if (hc && !hc.isNull()) cam = hc;
        } catch (_) {}
      }
      if (!cam) {
        try { cam = need('UnityEngine.Camera').method('get_main').invoke() as Il2Cpp.Object; } catch (_) {}
      }
      if (cam && !cam.isNull()) {
        canvasObj!.method('set_worldCamera').invoke(cam);
        // Keep World Space (2) so it sits in front of you in VR
        canvasObj!.method('set_renderMode').invoke(2);
        log('canvas worldCamera assigned');
      } else {
        log('WARN: no camera for canvas — menu may be invisible');
      }
    }, null);
  }

  function placeInFront() {
    if (!root) return;
    const h = headTransform();
    step('place', () => {
      if (h && !h.isNull()) {
        const p = rd(h.method('get_position').invoke()); const f = rd(h.method('get_forward').invoke());
        const len = Math.hypot(f[0], f[2]) || 1; const fx = f[0] / len, fz = f[2] / len;
        const pos = v3(p[0] + fx * cfg.distance, p[1] - 0.05, p[2] + fz * cfg.distance);
        root!.tf.method('set_position').invoke(pos);
        const rot: any = need('UnityEngine.Quaternion').method('LookRotation', 1).invoke(v3(fx, 0, fz));
        root!.tf.method('set_rotation').invoke(rot);
      } else {
        // Fallback: put panel at a visible default in front of origin
        root!.tf.method('set_position').invoke(v3(0, 1.5, 1.0));
        log('place fallback (no head) at 0,1.5,1');
      }
    }, null);
  }
  function setOpen(o: boolean) {
    if (!root) { log('setOpen ignored — root not built yet'); return; }
    menuOpen = o;
    if (o) {
      findPlayer();
      assignCanvasCamera();
      placeInFront();
      applyScale();
      // Ensure scale is visible (cfg.scale 1 => 0.001 world units ≈ 0.64m wide panel)
      step('force scale', () => {
        const s = 0.001 * Math.max(cfg.scale, 0.8);
        root!.tf.method('set_localScale').invoke(v3(s, s, s));
      }, null);
    }
    step('setActive', () => root!.go.method('SetActive').invoke(o), null);
    log('menu ' + (o ? 'OPEN' : 'CLOSED') + ' (root active)');
  }

  // ---------- per-frame tick ----------
  let chordWas = false, trigWas = false, tickCount = 0, lastPlayerCheck = 0, errStreak = 0, buildTried = false, autoOpened = false;
  let lastCeilingStrip = 0, sceneRecoverCount = 0;

  function rootAlive(): boolean {
    if (!root || !root.go) return false;
    return step('root alive', () => {
      try {
        // Destroyed Unity objects throw or report null on native handle access
        const name = root!.go.method('get_name').invoke();
        return name != null;
      } catch (_) { return false; }
    }, false);
  }

  function playerAlive(): boolean {
    if (!player) return false;
    return step('player alive', () => {
      try {
        player!.method('get_gameObject').invoke();
        return true;
      } catch (_) { return false; }
    }, false);
  }

  function recoverAfterScene() {
    sceneRecoverCount++;
    log('scene change detected — rebuilding menu (#' + sceneRecoverCount + ')');
    // Drop stale refs
    player = null; ctrl = null; inputP = null; playerLogged = false;
    leftPlat = null; rightPlat = null;
    try { clearEspLabels(); } catch (_) {}
    root = null; canvasObj = null; cursor = null;
    btns.length = 0;
    for (const k of Object.keys(tabRoots)) delete tabRoots[k];
    valueLabels.length = 0;
    builtOnce = false;
    buildTried = false;
    autoOpened = false;
    menuOpen = false;
    hover = null;
    // Rebuild on next ticks (main thread)
  }

  function stripCeilingsAndBarriers() {
    // Aggressive: disable ANY collider above the player and anything named like a barrier
    step('strip ceilings', () => {
      const colClass = need('UnityEngine.Collider');
      const findAll = need('UnityEngine.Object').method('FindObjectsOfType', 1);
      const arr = findAll.invoke(colClass.type.object) as any;
      if (!arr) return;
      let n = 0;
      const head = headTransform();
      let headY = 1.5, headX = 0, headZ = 0;
      if (head) {
        try {
          const hp = rd(head.method('get_position').invoke() as any);
          headX = hp[0]; headY = hp[1]; headZ = hp[2];
        } catch (_) {}
      }
      // Also try player feet position
      let playerY = headY;
      try {
        const ptf = playerTransform();
        if (ptf) playerY = rd(ptf.method('get_position').invoke() as any)[1];
      } catch (_) {}

      const nameRe = (s: string) => /ceiling|barrier|bound|roof|sky|kill|out.?of.?bound|map.?limit|height|invisible|anti.?fly|top.?bound|wall.?top|cover|lid|dome|cage|fence|block|limit|restrict|boundary|collider.?wall|mesh.?wall|trigger.?zone|death|void|arena.?top|map.?roof|play.?area|soft.?wall|hard.?wall/.test(s);

      for (const c of arr) {
        try {
          const col = c as Il2Cpp.Object;
          if (!col || col.isNull()) continue;
          // Skip our own grip platforms
          const go = col.method('get_gameObject').invoke() as Il2Cpp.Object;
          if (!go || go.isNull()) continue;
          const gname = String(go.method('get_name').invoke() || '');
          const gnameL = gname.toLowerCase();
          if (gnameL.indexOf('pvtx_') === 0) continue;

          const tf = go.method('get_transform').invoke() as Il2Cpp.Object;
          const pos = rd(tf.method('get_position').invoke() as any);

          // Bounds center can differ from transform.position — try collider bounds
          let cy = pos[1];
          try {
            const bounds = col.method('get_bounds').invoke() as any;
            if (bounds) {
              const center = bounds.field ? bounds.field('m_Center') : null;
              // bounds.center via method
              const bc = col.method('get_bounds').invoke() as Il2Cpp.Object;
              // Access center through bounds - use ClosestPoint or just position
            }
          } catch (_) {}

          const nameHit = nameRe(gnameL);
          // Anything whose transform is above head (with small margin) — disable while flying
          const aboveHead = pos[1] > playerY + 0.3;
          // Large objects that span above us (world scale Y high or positioned high)
          let bigHigh = false;
          try {
            const sc = rd(tf.method('get_localScale').invoke() as any);
            bigHigh = (pos[1] + Math.abs(sc[1]) * 0.5) > playerY + 1.0 && pos[1] > playerY - 2;
          } catch (_) {}

          if (nameHit || aboveHead || bigHigh) {
            col.method('set_enabled').invoke(false);
            n++;
          }
        } catch (_) {}
      }
      if (n > 0) log('disabled ' + n + ' overhead/barrier colliders');
      else log('strip ceilings: no matching colliders this pass');
    }, null);
  }

  function setPlayerCollisions(enabled: boolean) {
    // Nuclear option: while flying, turn off rigidbody collision detection so NOTHING blocks you
    const rb = rigidBody();
    if (!rb) return;
    step('detectCollisions', () => {
      try { rb.method('set_detectCollisions').invoke(enabled); } catch (_) {}
      try {
        // Also clear all constraints
        rb.method('set_constraints').invoke(0);
      } catch (_) {}
      try { rb.method('set_useGravity').invoke(enabled && state.grav && !state.fly); } catch (_) {}
    }, null);
    // Disable all colliders on the local player body (so we don't push ourselves)
    step('player cols', () => {
      try {
        const go = (playerTransform() as Il2Cpp.Object);
        if (!go) return;
        // get_gameObject from transform
        const g = (player as Il2Cpp.Object).method('get_gameObject').invoke() as Il2Cpp.Object;
        if (!g || g.isNull()) return;
        const arr = g.method('GetComponentsInChildren', 2).invoke(need('UnityEngine.Collider').type.object, true) as any;
        let n = 0;
        for (const c of arr) {
          try {
            // When flying: make them triggers (no physical block) instead of fully off if possible
            const col = c as Il2Cpp.Object;
            if (enabled) {
              col.method('set_isTrigger').invoke(false);
              col.method('set_enabled').invoke(true);
            } else {
              col.method('set_isTrigger').invoke(true);
            }
            n++;
          } catch (_) {}
        }
        if (n > 0 && !enabled) log('player colliders → trigger mode (' + n + ') for fly-through');
      } catch (_) {}
    }, null);
  }

  function breakHeightClamp() {
    if (!state.fly && state.grav && !state.noclip) return;
    step('height clamp break', () => {
      const rb = rigidBody();
      if (rb) {
        try {
          const constraints = Number(rb.method('get_constraints').invoke());
          if (constraints !== 0) {
            rb.method('set_constraints').invoke(0);
            log('cleared all rigidbody constraints');
          }
        } catch (_) {}
        try { rb.method('set_detectCollisions').invoke(false); } catch (_) {}
      }
    }, null);
  }

  function readBoolField(obj: Il2Cpp.Object, names: string[]): boolean {
    for (const n of names) {
      try {
        const v = obj.field(n).value;
        if (v === true || v === 1 || v === 1.0) return true;
        if (typeof v === 'number' && v > 0.5) return true;
      } catch (_) {}
    }
    return false;
  }
  function tick() {
    tickCount++;
    if (tickCount === 1) log('first tick received (per-frame hook is firing).');

    // Detect scene unload (lobby ↔ match): Unity destroys our root
    if (builtOnce && !rootAlive()) {
      recoverAfterScene();
    }

    if (!builtOnce) {
      if (!buildTried && tickCount >= 60) {
        buildTried = true;
        log('building panel on main thread (tick ' + tickCount + ')...');
        try { build(); } catch (e) { console.error(P + 'BUILD FAILED: ' + e); }
      }
      // After recovery, rebuild sooner
      if (!buildTried && sceneRecoverCount > 0) {
        buildTried = true;
        log('rebuilding panel after scene change...');
        try { build(); } catch (e) { console.error(P + 'REBUILD FAILED: ' + e); }
      }
      return;
    }

    // Re-bind player often — match spawn replaces the local player object
    if (tickCount - lastPlayerCheck > 45) {
      lastPlayerCheck = tickCount;
      if (!playerAlive()) {
        player = null; ctrl = null; inputP = null; playerLogged = false;
        findPlayer();
      }
    }

    // Auto-open once after each build/rebuild
    if (!autoOpened && builtOnce) {
      autoOpened = true;
      log('auto-opening menu (toggle: L-Grip+L-Trigger or R-Grip+R-Trigger)');
      setOpen(true);
    }

    // Strip ceilings often while flying / noclip (game may re-enable colliders)
    if (tickCount - lastCeilingStrip > 30) {
      lastCeilingStrip = tickCount;
      if (state.fly || state.noclip) {
        stripCeilingsAndBarriers();
        breakHeightClamp();
        setPlayerCollisions(false);
      }
    }
    // chord: L-Grip+L-Trigger OR R-Grip+R-Trigger (more field-name tolerant)
    let chord = false, trig = false;
    if (inputP) {
      const lg = readBoolField(inputP, ['leftGripPressed', 'leftGrip', 'LeftGripPressed', 'gripLeft']);
      const lt = readBoolField(inputP, ['leftTriggerPressed', 'leftTrigger', 'LeftTriggerPressed', 'triggerLeft']);
      const rg = readBoolField(inputP, ['rightGripPressed', 'rightGrip', 'RightGripPressed', 'gripRight']);
      const rt = readBoolField(inputP, ['rightTriggerPressed', 'rightTrigger', 'RightTriggerPressed', 'triggerRight']);
      chord = (lg && lt) || (rg && rt);
      trig = rt;
    }
    if (chord && !chordWas) {
      log('chord detected → toggle menu (was ' + menuOpen + ')');
      setOpen(!menuOpen);
    }
    chordWas = chord;
    if (!menuOpen) flyStep(trig);
    if ((state.fly || !state.grav) && tickCount % 60 === 0) applyPhysics();
    gripPlatformStep();
    modTick();
    if (!menuOpen || !root) { trigWas = trig; return; }
    if (cfg.follow && tickCount % 2 === 0) placeInFront();
    if (tickCount % 30 === 0) {
      valueLabels.forEach(v => step('val', () => v.t.method('set_text').invoke(Il2Cpp.string(v.get())), null));
      if (playerInfo) step('pinfo', () => playerInfo!.method('set_text').invoke(Il2Cpp.string(player ? 'Local player: verified\nSpeedMul=' + Number(player.field('speedMul').value).toFixed(2) : 'Local player: not spawned yet')), null);
    }
    if (!ctrl) { setHover(null); trigWas = trig; return; }
    // ray from right hand onto canvas plane (canvas-local space, origin at panel centre)
    const hit = step('ray', () => {
      const hand = ctrl!.field('rightHandTransform').value as Il2Cpp.Object;
      const o = rd(root!.tf.method('InverseTransformPoint').invoke(hand.method('get_position').invoke() as any));
      const d = rd(root!.tf.method('InverseTransformDirection').invoke(hand.method('get_forward').invoke() as any));
      if (Math.abs(d[2]) < 1e-5) return null;
      const t = -o[2] / d[2]; if (t <= 0) return null;
      return [o[0] + t * d[0], o[1] + t * d[1]] as [number, number];
    }, null);
    let h: Btn | null = null;
    if (hit) {
      for (const b of btns) {
        if (b.tab !== '*' && b.tab !== cfg.tab) continue;
        if (Math.abs(hit[0] - b.x) <= b.w / 2 && Math.abs(hit[1] - b.y) <= b.h / 2) { h = b; break; }
      }
      step('cursor', () => { cursor!.go.method('SetActive').invoke(Math.abs(hit[0]) < 320 && Math.abs(hit[1]) < 220); cursor!.rt.method('set_anchoredPosition').invoke(v2(hit[0], hit[1])); }, null);
    } else step('cursor off', () => cursor!.go.method('SetActive').invoke(false), null);
    setHover(h);
    if (trig && !trigWas && h) { if (cfg.diag) log('click: ' + h.id); step('click ' + h.id, () => h!.onClick(), null); btns.forEach(refreshBtn); }
    trigWas = trig;
  }
  function setHover(h: Btn | null) { if (h === hover) return; const old = hover; hover = h; if (old) refreshBtn(old); if (h) refreshBtn(h); }

  // ---------- tick hook ----------
  // NOTE: On this Quest build, method.implementation is broken ("already replaced by a thunk").
  // We ONLY use Interceptor.attach on native addresses, never .implementation.

  function methodAddr(m: any): any {
    try {
      if (m.virtualAddress && !m.virtualAddress.isNull()) return m.virtualAddress;
    } catch (_) {}
    try {
      if (m.handle && !m.handle.isNull()) return m.handle;
    } catch (_) {}
    try {
      // frida-il2cpp-bridge older API
      if (typeof m.toString === 'function') {
        const s = String(m);
      }
    } catch (_) {}
    return null;
  }

  function attachTick(addr: any, label: string): boolean {
    if (!addr) return false;
    try {
      if (addr.isNull && addr.isNull()) return false;
      Interceptor.attach(addr, {
        onEnter() {
          try { tick(); errStreak = 0; } catch (e) {
            if (errStreak++ < 3) console.warn(P + 'tick error: ' + e);
          }
        }
      });
      log('Interceptor OK: ' + label + ' @ ' + addr);
      return true;
    } catch (e) {
      console.warn(P + 'Interceptor FAIL ' + label + ': ' + e);
      return false;
    }
  }

  function tryInterceptorOnClass(cn: string): string | null {
    const c = K(cn); if (!c) return null;
    for (const methodName of ['Update', 'LateUpdate', 'FixedUpdate']) {
      const m = step('resolve ' + cn + '.' + methodName, () => {
        try { return c.tryMethod(methodName, 0); } catch (_) { return null; }
      }, null);
      if (!m) continue;
      const addr = methodAddr(m);
      if (attachTick(addr, cn + '.' + methodName)) return cn + '.' + methodName + ' (interceptor)';
    }
    // Try any method with "Update" in the name
    try {
      for (const m of (c as any).methods) {
        const n = String(m.name || '');
        if (/update/i.test(n) && m.parameterCount === 0) {
          const addr = methodAddr(m);
          if (attachTick(addr, cn + '.' + n)) return cn + '.' + n + ' (interceptor)';
        }
      }
    } catch (_) {}
    return null;
  }

  function tryTimeDeltaHook(): string | null {
    // Time.get_deltaTime is called every frame by Unity
    const names = [
      ['UnityEngine.Time', 'get_deltaTime'],
      ['UnityEngine.Time', 'get_time'],
      ['UnityEngine.Time', 'get_frameCount'],
    ];
    for (const [cn, mn] of names) {
      const c = K(cn); if (!c) continue;
      const m = step('resolve ' + cn + '.' + mn, () => {
        try { return c.tryMethod(mn, 0); } catch (_) { return null; }
      }, null);
      if (!m) continue;
      const addr = methodAddr(m);
      // Throttle: Time.get_deltaTime can fire multiple times per frame
      let last = 0;
      if (!addr) continue;
      try {
        Interceptor.attach(addr, {
          onEnter() {
            const now = Date.now();
            if (now - last < 8) return; // ~120Hz max
            last = now;
            try { tick(); errStreak = 0; } catch (e) {
              if (errStreak++ < 3) console.warn(P + 'tick error: ' + e);
            }
          }
        });
        log('Interceptor OK: ' + cn + '.' + mn + ' @ ' + addr);
        return cn + '.' + mn + ' (interceptor)';
      } catch (e) {
        console.warn(P + 'Time hook fail: ' + e);
      }
    }
    return null;
  }

  function startIntervalTick(): string {
    // Last resort: JS timer. Il2Cpp.perform marshals onto a safe context in the bridge.
    log('starting setInterval tick fallback (16ms)');
    setInterval(() => {
      try {
        Il2Cpp.perform(() => {
          try { tick(); errStreak = 0; } catch (e) {
            if (errStreak++ < 3) console.warn(P + 'tick error: ' + e);
          }
        });
      } catch (e) {
        if (errStreak++ < 3) console.warn(P + 'interval tick: ' + e);
      }
    }, 16);
    return 'setInterval(16ms)';
  }

  function hookTick(): string | null {
    const candidates: string[] = [
      'Cydream.GameManager',
      'Cydream.InputProcessor',
      'Cydream.MenuManager',
      'GameManager',
      'InputProcessor',
      'GTController',
      'GTPlayer',
      'RawInputProcessor',
      'OVRCameraRig',
      'OVRManager',
      'OVRInput',
      'UnityEngine.EventSystems.EventSystem',
    ];
    for (const cn of candidates) {
      const r = tryInterceptorOnClass(cn);
      if (r) return r;
    }
    log('class Update interceptors failed — trying Time.get_deltaTime');
    const t = tryTimeDeltaHook();
    if (t) return t;

    log('scanning assemblies for Update methods...');
    const hits = scan('GameManager|InputProcessor|MenuManager|GTController|GTPlayer|OVR|Player');
    hits.slice(0, 15).forEach(x => log('  candidate: ' + x));
    for (const line of hits) {
      const full = line.split('  [')[0].trim();
      if (!full) continue;
      const r = tryInterceptorOnClass(full);
      if (r) return r;
    }

    // Absolute fallback so the menu can still build
    return startIntervalTick();
  }

  function scan(re: string, max = 60): string[] {
    const rx = new RegExp(re, 'i'); const out: string[] = [];
    for (const a of Il2Cpp.domain.assemblies) {
      try { for (const c of a.image.classes) { if (rx.test(c.fullName)) { out.push(c.fullName + '  [' + a.name + ']'); if (out.length >= max) return out; } } } catch (_) {}
    }
    return out;
  }
  function scanLog(re: string) { const r = scan(re); log('scan /' + re + '/ -> ' + r.length + ' hits'); r.forEach(x => log('  ' + x)); }

  // ---------- startup ----------
  log('SOUNDBOARD BUILD: chunked WAV conversion + streaming local AudioTrack + PCM16 WAV VC injection.');
  log('starting; built-in MenuManager.OpenMenu/OpenGraphicMenu are never called.');
  const hooked = hookTick();   // panel is built later, from inside the first ticks (main thread)
  if (hooked) log('per-frame tick hooked on ' + hooked + ' (verify it actually fires: look for "first tick" below).');
  else console.error(P + 'NO per-frame hook found; menu cannot be driven. Share this log.');

  // Watchdog: if first tick never arrives, force interval fallback
  let watchdogTries = 0;
  let intervalStarted = hooked != null && hooked.indexOf('setInterval') >= 0;
  const watchdog = setInterval(() => {
    watchdogTries++;
    if (tickCount > 0) {
      if (watchdogTries > 2) { try { clearInterval(watchdog); } catch (_) {} }
      return;
    }
    log('watchdog: no tick yet (try ' + watchdogTries + ')');
    if (!intervalStarted) {
      intervalStarted = true;
      startIntervalTick();
      log('watchdog started setInterval fallback');
    }
    if (watchdogTries >= 3) {
      // Direct force build from timer if still nothing
      try {
        Il2Cpp.perform(() => {
          if (!builtOnce) {
            log('watchdog forceBuild');
            try { build(); setOpen(true); } catch (e) { console.error(P + 'watchdog build: ' + e); }
          }
        });
      } catch (e) { console.warn(P + 'watchdog perform: ' + e); }
      try { clearInterval(watchdog); } catch (_) {}
    }
  }, 1500);

  rpc.exports = {
    dispose() { Il2Cpp.perform(() => { destroyGripPlatforms(); destroyOld(); log('disposed'); }); },
    open() { Il2Cpp.perform(() => { if (!builtOnce) { try { build(); } catch (e) { console.error(P + e); } } setOpen(true); }); },
    close() { Il2Cpp.perform(() => setOpen(false)); },
    toggle() { Il2Cpp.perform(() => setOpen(!menuOpen)); },
    forceBuild() { Il2Cpp.perform(() => { try { if (!builtOnce) build(); setOpen(true); log('forceBuild done built=' + builtOnce); } catch (e) { console.error(P + 'forceBuild: ' + e); } }); },
    scan(re: string) { Il2Cpp.perform(() => scanLog(re)); },
    status() {
      return {
        built: builtOnce,
        open: menuOpen,
        player: !!player,
        ctrl: !!ctrl,
        inputP: !!inputP,
        ticks: tickCount,
        hooked: hooked,
        gripPlatforms: state.gripPlatforms,
      };
    },
  };
});
