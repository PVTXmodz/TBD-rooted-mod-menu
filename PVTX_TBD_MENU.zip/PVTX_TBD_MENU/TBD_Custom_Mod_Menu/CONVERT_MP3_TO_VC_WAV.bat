@echo off
setlocal EnableExtensions EnableDelayedExpansion
title PVTX Soundboard - Convert MP3 to VC WAV
set "SOUNDDIR=%~dp0sounds"
echo ============================================================
echo   PVTX Soundboard - MP3 to VC-compatible WAV converter
echo ============================================================
where ffmpeg >nul 2>&1
if errorlevel 1 (
  echo [ERROR] FFmpeg was not found in PATH.
  echo Install FFmpeg for Windows and ensure ffmpeg.exe is on PATH,
  echo then run this file again. No original MP3 will be changed.
  echo Alternatively, export each clip as WAV, signed 16-bit PCM,
  echo mono, 16000 Hz, and trim it to 10 seconds or less.
  pause
  exit /b 1
)
if not exist "%SOUNDDIR%\." (
  echo [ERROR] Sounds folder not found: "%SOUNDDIR%"
  pause
  exit /b 1
)
set /a FOUND=0
set /a OK=0
for %%F in ("%SOUNDDIR%\*.mp3") do (
  if exist "%%~fF" (
    set /a FOUND+=1
    echo.
    echo [INFO] Converting %%~nxF to mono PCM16 WAV, 16000 Hz, max 10 seconds...
    ffmpeg -hide_banner -loglevel error -y -i "%%~fF" -t 10 -vn -ac 1 -ar 16000 -c:a pcm_s16le "%%~dpnF.wav"
    if errorlevel 1 (
      echo [ERROR] Conversion failed for %%~nxF
    ) else (
      set /a OK+=1
      echo [OK] Created %%~nF.wav
    )
  )
)
if !FOUND! EQU 0 (
  echo [INFO] No MP3 files found in "%SOUNDDIR%".
) else (
  echo.
  echo [INFO] Converted !OK! of !FOUND! MP3 file(s).
  echo The original MP3 files were kept. WAV output is capped at 10 seconds
  echo and should fit the 1 MB source limit at this format.
  echo Run BUILD_AND_RUN.bat afterward to sync WAV files to the Quest.
)
echo.
pause
