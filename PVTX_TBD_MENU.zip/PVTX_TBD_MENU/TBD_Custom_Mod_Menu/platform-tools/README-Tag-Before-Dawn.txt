TAG BEFORE DAWN - CLEAN MENU

This version removes the legacy menu dependencies and starts with a Tag Before Dawn-only menu foundation.

Removed from the active source:
- legacy Gorilla Tag player classes
- legacy menu/button classes
- old network-player helpers
- old Photon-specific menu code
- old test/debug helpers
- old weapon/rig/crash/destroy/monster helpers
- old gun-pointer/tag-gun code

Current menu features:
- Fly
- Platforms
- Noclip
- Super Jump
- Super Speed
- Stop Velocity
- Teleport Forward
- Low Gravity
- Freeze Local
- Ghost Visual
- Fly speed settings
- Platform color settings

The menu no longer looks up any of the removed legacy classes during startup.
It uses generic Unity/IL2CPP objects and a controller ray for menu button selection.

run.bat expects:
  platform-tools\\adb.exe

The Quest target is configured as:
  340YC10G8M057G

Package:
  com.Cydream.TagBeforeDawn

If the game uses different player/physics classes, movement features may need a later
Tag Before Dawn-specific class mapping. The important difference is that the menu itself
will not crash because an old legacy class is missing.
